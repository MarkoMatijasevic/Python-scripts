
import pandas as pd
import os
pwd = os.getcwd()


dataset = pd.read_excel ("C:/Users/Marko/OneDrive/Desktop/Marko/PYTHON/automobili.xlsx")

print(dataset)





