# txt = "Hello World"[::-1]
# print(txt)




#Opcija 2
def reverse(s):
    s=s.split()
    s.reverse()
    return s

print(reverse("This is the best"))




# #Opcija 3
# def reverse(s):
#     return " ".join(reversed(s.split()))
# print (reverse("This is the best"))




