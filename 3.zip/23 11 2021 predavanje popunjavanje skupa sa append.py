


mat=[]
for i in range (8):
    vrsta=[]
    for j in range(8):
        vrsta.append(j+1)
    mat.append(vrsta)
print(mat)
print(mat[5])
