sirina=10
for i in range(sirina):
    for j in range(i):
        
            print("*",end="")
    print()

str=""
for i in range(sirina):
    str+="#"
    print(str)
  
