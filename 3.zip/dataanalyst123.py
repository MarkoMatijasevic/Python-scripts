from tkinter.tix import COLUMN
import pandas as pd
import os

dataset=pd.read_excel("C:/Users/Marko/OneDrive/Desktop/Marko/PYTHON/automobili.xlsx")

# print(dataset)

# print(dataset.columns)
dataset_modified=dataset.copy
# print(dataset_modified)
dataset_modified.drop(COLUMN('Unnamed: 0'))
print(dataset_modified)