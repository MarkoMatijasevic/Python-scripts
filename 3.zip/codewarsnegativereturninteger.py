#resenje
def make_negative(num):
    if num > 0:
        return num * (-1)
    elif num < 0: 
        return num
    else:
        return 0



#moja opcija 1 koja nije bila dobra ali vraca broj koji treba
def make_negative(number):
    if number<=0:
        print(number)
      
    else:
        print(number-number*2)
        

make_negative(5)




#opcija2

def make_negative(number):
    return print(number*-1)

make_negative(9)