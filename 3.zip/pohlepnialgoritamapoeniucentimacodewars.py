def loose_change(num):
    
    
    data = {
        "Pennies":0,
        "Nickels":0,
        "Dimes":0,
        "Quarters":0
    }
    
    if num <0:
        return data
    else:
        data["Quarters"] = num//25
        num=num-(data["Quarters"]*25)
        data["Dimes"]= num//10
        num=num - (data["Dimes"]*10)
        data["Nickels"] = num//5
        num=num-(data["Nickels"]*5)
        data["Pennies"]=num
    
    return data

print(loose_change(56))


    
    
                
    
    



