a=[5,7,3,8,9]
print(a)
x=a[4]
for i in range(0,len(a)-1):
    a[len(a)-1-i]=a[len(a)-2-i]
a[0]=x
print(a)
