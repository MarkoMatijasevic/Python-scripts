
def func_constant(values):
    print(values[0])

func_constant([1,2,3,])





# def Big_O_Notation(n):
#     return 45*n**3+20*n**2+19

# print(Big_O_Notation(10))



# Kvadratna slozenost 
# def func_quadratic(list):
#     for item_1 in list:
#         for item_2 in list:
#             print(item_1,item_2)
# list=[1,2,3]

# print(func_quadratic(list))
