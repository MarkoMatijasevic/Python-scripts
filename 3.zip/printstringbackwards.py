txt = "357"[::-1]
print(txt)


