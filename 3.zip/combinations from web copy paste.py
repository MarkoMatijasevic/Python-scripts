from itertools import compress, product

def combinations(items):
    return ( set(compress(items,mask)) for mask in product([0,1], repeat=len(items)) )

print(combinations("Marko"))