def number_of_rectangles(a, b):
    return a*b*(b+1)*(a+1)//4

print(number_of_rectangles(4,4))


#Objasnjenje:

# #If the grid is 1×1, there is 1 rectangle. 
# the grid is 2×1, there will be 2 + 1 = 3 rectangles 
# If it grid is 3×1, there will be 3 + 2 + 1 = 6 rectangles. 
# we can say that for N*1 there will be N + (N-1) + (n-2) … + 1 = (N)(N+1)/2 rectangles
# If we add one more column to N×1, firstly we will have as many rectangles in the 2nd column as the first, 
# and then we have that same number of 2×M rectangles. 
# So N×2 = 3 (N)(N+1)/2
# After deducing this we can say 
# For N*M we’ll have (M)(M+1)/2 (N)(N+1)/2 = M(M+1)(N)(N+1)/4
# So the formula for total rectangles will be M(M+1)(N)(N+1)/4 