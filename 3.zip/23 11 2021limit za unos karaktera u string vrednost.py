# while True:
#     answer = input("What's up, doc? ")
#     if len(answer) <= 10:
#         break
#     else:
#         print("Too much info - keep it shorter!")



# def fun():
#     return [i for i in range (0,21,3)]
# print(fun())
