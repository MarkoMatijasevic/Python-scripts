def anagram(s1,s2):
    s1 = s1.replace(' ','').lower() # removes spaces
    s2 = s2.replace(' ','').lower() # removes spaces
    return sorted(s1)==sorted(s2) # returns boolean ( True/False) for sorted match


print(anagram('dog','god'))

print(anagram('clint eastwood','old west action'))

print(anagram('aa','bb'))