#import numpy as np

#Why Use NumPy?

#In Python we have lists that serve the purpose of arrays, but they are slow to process.

#NumPy aims to provide an array object that is up to 50x faster than traditional Python lists.

#The array object in NumPy is called ndarray, it provides a lot of supporting functions that make working with ndarray very easy.

#Arrays are very frequently used in data science, where speed and resources are very important.

#Data Science: is a branch of computer science where we study how to store, use and analyze data for deriving information from it.

#pip install numpy

import numpy as np


# Vector
v = np.array([1, 3, 5, 7])
print(v)


# Matrix
A = np.mat([[1, 2], [3, 3]])
print(A)
# Out:  matrix([[1, 2], [3, 3]])


# Adding, subtracting, multiplying matrixes
print(A + A)
# Out: matrix([[2, 4], [6, 6]])

print(A - A)
# Out: matrix([[0, 0], [0, 0]])

print(A * A)
# Out:  matrix([[ 7, 8], [12, 15]])


# Determinant of a matrix
print(np.linalg.det(A))
# Out: -3.0000000000000004
# Notice the margin of error is due to floating point arithmetics


# Transposing a matrix
print(np.matrix.transpose(A))
# Out[12]: matrix([[1, 3], [2, 3]])

#-----------------------------------

#import numpy as np

A = np.mat([[1, 2, 3], [4, 5, 6], [7, 8, 9]])

print('A * A: ', A * A)

print('det(A): ', np.linalg.det(A))

print('transpose(A): ', np.matrix.transpose(A))

#-----------------------------------

arr = np.arange(1,5)
print(arr)

arr = np.array([1,2,3,4,5])
print(arr)

arr = np.array([1.,2,3,4,5])
print(arr)

arr = np.array([1,2,3,4,5],dtype=np.bool)
print(arr)

arr = np.array([[1,2,3],[4,5,6]])
print(arr)
print(arr*2)
print(arr+2)
print(np.array([1,2,3])+np.array([2,3,4]))

a = np.array([[1,2],[3,4]])
b = np.array([[1,2],[4,5]])
print(a*b)

arr = np.mat([[1, 2, 3, 4], [5, 6, 7, 8]]) 
print('shape of array :', arr.shape) 
arr = arr.reshape(4,2)
print(arr)

print("Reshape From 1-D to 3-D")
arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
newarr = arr.reshape(2, 3, 2)
print(newarr) 

#Unknown Dimension

#You are allowed to have one "unknown" dimension.

#Meaning that you do not have to specify an exact number for one of the dimensions in the reshape method.

#Pass -1 as the value, and NumPy will calculate this number for you.

#Convert 1D array with 8 elements to 3D array with 2x2 elements:

arr = np.array([1, 2, 3, 4, 5, 6, 7, 8])
newarr = arr.reshape(2, 2, -1)
print(newarr) 

arr = [[[1],[2],[3]]]
print(np.squeeze(arr))

mat = np.eye(4)
print(mat)
mat = np.identity(4)
print(mat)

a = np.array([1,2])
b = np.array([[1,2],[3,4]])
c = np.matmul(a,b)
print(c)

a = np.array([1,2])
b = np.array([[1,2],[3,4]])
c = a@b
print(c)

arr = np.array([1, 2, 3, 4], ndmin=5)

arr = np.mat([[1, 2, 3, 4], [5, 6, 7, 8]])
print(arr.ndim)

print(arr)
print('number of dimensions :', arr.ndim)

arr = np.array([1, 2, 3, 4])
print(arr[2] + arr[3])

arr = np.array([[1,2,3,4,5], [6,7,8,9,10]])
print('2nd element on 1st dim: ', arr[0, 1]) 

arr = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
print(arr[0, 1, 2]) 

arr = np.array([[1,2,3,4,5], [6,7,8,9,10]])
print('Last element from 2nd dim: ', arr[1, -1]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[1:5]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[:4]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[-3:-1]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[1:5:2]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7]) # korak 2 u celom nizu
print(arr[::2]) 

arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]) # deluj na prvi niz
print(arr[1, 1:4]) 

arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]) # za oba niza broj sa indeksa 2
print(arr[0:2, 2]) 

arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])
print(arr[0:2, 1:4]) 

arr = np.array([1.1, 2.1, 3.1])
print(arr)
newarr = arr.astype('i')
print(newarr)

arr = np.array([1.1, 2.1, 3.1])
newarr = arr.astype(int)
print(newarr)

arr = np.array([1, 0, 3])
newarr = arr.astype(bool)
print(newarr)
print(newarr.dtype) 

#-----------------------------------

#The Difference Between Copy and View

#The main difference between a copy and a view of an array is that the copy is a new array, and the view is just a view of the original array.

import numpy as np

arr = np.array([1, 2, 3, 4, 5])
x = arr.copy()
arr[0] = 42
print(arr)
print(x)

arr = np.array([1, 2, 3, 4, 5])
x = arr.view()
arr[0] = 42
print(arr)
print(x)  

arr = np.array([1, 2, 3, 4, 5])
x = arr.view()
x[0] = 31
print(arr)
print(x) 

arr = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
for x in arr:
  for y in x:
    for z in y:
      print(z) 
	  
arr1 = np.array([1, 2, 3])
arr2 = np.array([4, 5, 6])
arr = np.concatenate((arr1, arr2))
print(arr) 	 

#-- PRETRAGE -- 

arr = np.array([1, 2, 3, 4, 5, 4, 4])
x = np.where(arr == 4)
print(x) 

arr = np.array([1, 2, 3, 4, 5, 6, 7, 8])
x = np.where(arr%2 == 0)
print(x) 

# podrazumeva se sortiranost
arr = np.array([6, 7, 8, 9])
x = np.searchsorted(arr, 7)
print(x)
x = np.searchsorted(arr, 5)
print(x)  

#Find the indexes where the value 7 should be inserted, starting from the right:
arr = np.array([6, 7, 8, 9])
x = np.searchsorted(arr, 7, side='right')
print(x) 

arr = np.array([41, 42, 43, 44])
x = [True, False, True, False]
newarr = arr[x]
print(newarr) 

#Create a filter array that will return only even elements from the original array:
arr = np.array([1, 2, 3, 4, 5, 6, 7])
# Create an empty list
filter_arr = []
# go through each element in arr
for element in arr:
  # if the element is completely divisble by 2, set the value to True, otherwise False
  if element % 2 == 0:
    filter_arr.append(True)
  else:
    filter_arr.append(False)
newarr = arr[filter_arr]
print(filter_arr)
print(newarr) 

arr = np.array([41, 42, 43, 44])
filter_arr = arr > 42
newarr = arr[filter_arr]
print(filter_arr)
print(newarr) 

#--------------------------

import matplotlib.pyplot as plt
import numpy as np

xpoints = np.array([0, 6])
ypoints = np.array([0, 250])
plt.plot(xpoints, ypoints)
plt.show()

xpoints = np.array([1, 8])
ypoints = np.array([3, 10])
plt.plot(xpoints, ypoints, 'o')
plt.show()

xpoints = np.array([1, 2, 6, 8])
ypoints = np.array([3, 8, 1, 10])
plt.plot(xpoints, ypoints)
plt.show()

# crtanje bez x koordinate, pocinje od nule
ypoints = np.array([3, 8, 1, 10, 5, 7])
plt.plot(ypoints)
plt.show()

ypoints = np.array([3, 8, 1, 10])
plt.plot(ypoints, marker = 'o')
plt.show()

ypoints = np.array([3, 8, 1, 10])
plt.plot(ypoints, marker = 'o', ms = 20, mfc = 'r',linestyle='--')
plt.show()

ypoints = np.array([3, 8, 1, 10])
plt.plot(ypoints, linewidth = '20.5',c = '#4CAF50')
plt.show()

y1 = np.array([3, 8, 1, 10])
y2 = np.array([6, 2, 7, 11])
plt.plot(y1)
plt.plot(y2)
plt.show()

# isto kao i ovo
x1 = np.array([0, 1, 2, 3])
y1 = np.array([3, 8, 1, 10])
x2 = np.array([0, 1, 2, 3])
y2 = np.array([6, 2, 7, 11])

plt.plot(x1, y1, x2, y2)
plt.show()

x = np.array([80, 85, 90, 95, 100, 105, 110, 115, 120, 125])
y = np.array([240, 250, 260, 270, 280, 290, 300, 310, 320, 330])

plt.title("Sports Watch Data")
plt.xlabel("Average Pulse")
plt.ylabel("Calorie Burnage")
plt.plot(x, y)
plt.grid()
plt.show() 

x = np.array([5,7,8,7,2,17,2,9,4,11,12,9,6])
y = np.array([99,86,87,88,111,86,103,87,94,78,77,85,86])
plt.scatter(x, y)
plt.show()

#day one, the age and speed of 13 cars:
x = np.array([5,7,8,7,2,17,2,9,4,11,12,9,6])
y = np.array([99,86,87,88,111,86,103,87,94,78,77,85,86])
plt.scatter(x, y)
#day two, the age and speed of 15 cars:
x = np.array([2,2,8,1,15,8,12,9,7,3,11,4,7,14,12])
y = np.array([100,105,84,105,90,99,90,95,94,100,79,112,91,80,85])
plt.scatter(x, y)
plt.show() 

x = np.array([5,7,8,7,2,17,2,9,4,11,12,9,6])
y = np.array([99,86,87,88,111,86,103,87,94,78,77,85,86])
plt.scatter(x, y, color = 'hotpink')
x = np.array([2,2,8,1,15,8,12,9,7,3,11,4,7,14,12])
y = np.array([100,105,84,105,90,99,90,95,94,100,79,112,91,80,85])
plt.scatter(x, y, color = '#88c999')
plt.show() 

x = np.array([5,7,8,7,2,17,2,9,4,11,12,9,6])
y = np.array([99,86,87,88,111,86,103,87,94,78,77,85,86])
colors = np.array([0, 10, 20, 30, 40, 45, 50, 55, 60, 70, 80, 90, 100])

plt.scatter(x, y, c=colors, cmap='viridis')
plt.colorbar()
plt.show() 

x = np.array([5,7,8,7,2,17,2,9,4,11,12,9,6])
y = np.array([99,86,87,88,111,86,103,87,94,78,77,85,86])
sizes = np.array([20,50,100,200,500,1000,60,90,10,300,600,800,75])
plt.scatter(x, y, s=sizes)
plt.show() 

x = np.random.randint(100, size=(100))
y = np.random.randint(100, size=(100))
colors = np.random.randint(100, size=(100))
sizes = 10 * np.random.randint(100, size=(100))
plt.scatter(x, y, c=colors, s=sizes, alpha=0.5, cmap='nipy_spectral')
plt.colorbar()
plt.show() 

x = np.array(["A", "B", "C", "D"])
y = np.array([3, 8, 1, 10])
plt.bar(x,y)
plt.show()

x = np.array(["A", "B", "C", "D"])
y = np.array([3, 8, 1, 10])
plt.bar(x, y, color = "red")
plt.show()

x = np.array(["A", "B", "C", "D"])
y = np.array([3, 8, 1, 10])
plt.bar(x, y, color = "#4CAF50")
plt.show()

x = np.random.normal(170, 10, 250)
print(x) 

x = np.random.normal(170, 10, 250)
plt.hist(x)
plt.show() 

y = np.array([35, 25, 25, 15])
mylabels = ["Apples", "Bananas", "Cherries", "Dates"]
plt.pie(y, labels = mylabels)
plt.show() 

x = np.random.uniform(0.0, 5.0, 250)
print(x) 
plt.hist(x, 5)
plt.show() 


x = np.random.normal(5.0, 1.0, 100000)
plt.hist(x, 100)
plt.show() 

#--------------------

import matplotlib.pyplot as plt
import numpy as np
from scipy import stats


#Mean - The average value
#Median - The mid point value
#Mode - The most common value

speed = [99,86,87,88,111,86,103,87,94,78,77,85,86]

x = np.mean(speed)
print(x)

x = np.median(speed)
print(x) 

x = stats.mode(speed)
print(x) 

speed = [86,87,88,86,87,85,86]
x = np.std(speed)
print(x) 

x = np.random.uniform(0.0, 5.0, 250)
print(x) 
plt.hist(x, 5)
plt.show() 


x = np.random.normal(5.0, 1.0, 100000)
plt.hist(x, 100)
plt.show() 

import matplotlib.pyplot as plt
from scipy import stats

x = [5,7,8,7,2,17,2,9,4,11,12,9,6]
y = [99,86,87,88,111,86,103,87,94,78,77,85,86]

slope, intercept, r, p, std_err = stats.linregress(x, y)

def myfunc(x):
  return slope * x + intercept

mymodel = list(map(myfunc, x))

plt.scatter(x, y)
plt.plot(x, mymodel)
plt.show() 

x = [89,43,36,36,95,10,66,34,38,20,26,29,48,64,6,5,36,66,72,40]
y = [21,46,3,35,67,95,53,72,58,10,26,34,90,33,38,20,56,2,47,15]

slope, intercept, r, p, std_err = stats.linregress(x, y)

def myfunc(x):
  return slope * x + intercept

mymodel = list(map(myfunc, x))

plt.scatter(x, y)
plt.plot(x, mymodel)
plt.show() 

	

