def fibb(n):
    a=0
    b=1
    for i in range(2,n+1):
        zbir=a+b
        a=b
        b=zbir
    return zbir
print(fibb(25))
