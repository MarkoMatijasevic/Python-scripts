# linearna slozenost O(n)
# n=2
# broj=0
# def sprat(boja,n):
#     global broj
#     if(n==0):
#         broj+=1
#         return
#     sprat("B", n-1)
#     sprat("P", n-1)
#     sprat("C", n-1)

# sprat("",n)
# print(broj) #ispisuje koliko varijanti ukupno ima - da se ispisu sve boje (crvena, bela, plava, bez ponavljanja crvena-crvena i tako dalje)





#modifikovana verzija ovog resenja koja je EKSPONENCIJALNA SLOZENOST (O2^n, dva na n)
# n=2
# broj=0
# def sprat(boja,n):
#     global broj
#     if(n==0):
#         broj+=1
#         return
#     for i in ["B","P","C"]:
#         sprat (i,n-1)



#ovo je da ne mogu tri uzastopna sprata biti obojena istom bojom, izbacuje koliko takbvih varijanti ima ukupno
n=3
broj=0
def sprat(boja,n,ind):
    global broj
    if(n==0):
        broj+=1
        return
    for i in ['B','P','C']:
        if(ind==True and boja==i):
            continue
        if(i==boja):
            sprat(i,n-1,True)
        else:
            sprat(i,n-1,False)


sprat('',n,False)
print(broj)


