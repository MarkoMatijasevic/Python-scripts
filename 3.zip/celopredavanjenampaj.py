import numpy as np

# Vector
v = np.array([1, 3, 5, 7])
print(v)

B = [[1, 2], [3, 3]]
C = []
for i in range(len(B)):
    C.append([])
for vrsta in range(len(B)):
    for i in B[vrsta]:
        C[vrsta].append(i+i)
print(C)

print(B)


# Matrix
A = np.mat([[1, 2], [3, 3]])
print(A)
print(A+A)
print(A*A)
J = np.identity(2)
print(A*J)
print(J*A)

print(np.linalg.det(A))

print(np.matrix.transpose(A))

A = np.mat([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(A)
print('A * A: ', A * A)
print('det(A): ', np.linalg.det(A))
print('transpose(A): ', np.matrix.transpose(A))

arr = np.arange(1,5)
print(arr)

arr = np.array([1,2,3,4,5])
print(arr)
arr = np.array([1.,2,3,4,5])
print(arr)

arr = np.array([0,2,3,4,5],dtype=np.bool)
print(arr)

arr = np.array([[1,2,3],[4,5,6]])
print(arr)
print(arr*2)
print(arr+2)
print(np.array([1,2,3])+np.array([2,3,4]))

a = np.array([[1,2],[3,4]])
b = np.array([[1,2],[4,5]])
print(a*b)

arr = np.mat([[1, 2, 3, 4], [5, 6, 7, 8]])
print(arr) 
print('shape of array :', arr.shape) 
arr = arr.reshape(4,2)
print(arr)

print("Reshape From 1-D to 3-D")
arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
newarr = arr.reshape(2, 3, 2)
print(newarr) 


arr = np.array([1, 2, 3, 4, 5, 6, 7, 8])
newarr = arr.reshape(2, 2, -1)
print(newarr) 

arr = [[[1],[2],[3]]]
print(np.squeeze(arr))

mat = np.eye(4)
print(mat)
mat = np.identity(4)
print(mat)

a = np.array([1,2])
b = np.array([[1,2],[3,4]])
c = np.matmul(a,b)
print(c)

a = np.array([1,2])
b = np.array([[1,2],[3,4]])
c = a@b
print(c)

arr = np.array([1, 2, 3, 4], ndmin=5)

arr = np.mat([[1, 2, 3, 4], [5, 6, 7, 8]])
print(arr.ndim)

print(arr)
print('number of dimensions :', arr.ndim)

arr = np.array([1, 2, 3, 4])
print(arr[2] + arr[3])

arr = np.array([[1,2,3,4,5], [6,7,8,9,10]])
print('2nd element on 1st dim: ', arr[0, 1]) 

arr = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
print(arr[0, 1, 2]) 

arr = np.array([[1,2,3,4,5], [6,7,8,9,10]])
print('Last element from 2nd dim: ', arr[1, -1]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[1:5]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[:4]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[-3:-1]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[1:5:2]) 

arr = np.array([1, 2, 3, 4, 5, 6, 7]) # korak 2 u celom nizu
print(arr[::2]) 

arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]) # deluj na prvi niz
print(arr[1, 1:4]) 

arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]) # za oba niza broj sa indeksa 2
print(arr[0:2, 2]) 

arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])
print(arr[0:2, 1:4]) 

arr = np.array([1.1, 2.1, 3.1])
print(arr)
newarr = arr.astype('i')
print(newarr)

arr = np.array([1.1, 2.1, 3.1])
newarr = arr.astype(int)
print(newarr)

arr = np.array([1, 0, 3])
newarr = arr.astype(bool)
print(newarr)
print(newarr.dtype) 

#-----------------------------------

#The Difference Between Copy and View

#The main difference between a copy and a view of an array is that the copy is a new array, and the view is just a view of the original array.

import numpy as np

arr = np.array([1, 2, 3, 4, 5])
x = arr.copy()
arr[0] = 42
print(arr)
print(x)

arr = np.array([1, 2, 3, 4, 5])
x = arr.view()
arr[0] = 42
print(arr)
print(x)  

arr = np.array([1, 2, 3, 4, 5])
x = arr.view()
x[0] = 31
print(arr)
print(x) 

arr = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
for x in arr:
  for y in x:
    for z in y:
      print(z) 
	  
arr1 = np.array([1, 2, 3])
arr2 = np.array([4, 5, 6])
arr = np.concatenate((arr1, arr2))
print(arr) 	 

#-- PRETRAGE -- 

arr = np.array([1, 2, 3, 4, 5, 4, 4])
x = np.where(arr == 4)
print(x) 

arr = np.array([1, 2, 3, 4, 5, 6, 7, 8])
x = np.where(arr%2 == 0)
print(x) 

# podrazumeva se sortiranost
arr = np.array([6, 7, 8, 9])
x = np.searchsorted(arr, 7)
print(x)
x = np.searchsorted(arr, 5)
print(x)  

#Find the indexes where the value 7 should be inserted, starting from the right:
arr = np.array([6, 7, 8, 9])
x = np.searchsorted(arr, 7, side='right')
print(x) 

arr = np.array([41, 42, 43, 44])
x = [True, False, True, False]
newarr = arr[x]
print(newarr) 

#Create a filter array that will return only even elements from the original array:
arr = np.array([1, 2, 3, 4, 5, 6, 7])
# Create an empty list
filter_arr = []
# go through each element in arr
for element in arr:
  # if the element is completely divisble by 2, set the value to True, otherwise False
  if element % 2 == 0:
    filter_arr.append(True)
  else:
    filter_arr.append(False)
newarr = arr[filter_arr]
print(filter_arr)
print(newarr) 

arr = np.array([41, 42, 43, 44])
filter_arr = arr > 42
newarr = arr[filter_arr]
print(filter_arr)
print(newarr) 
