suma=100
deset=suma//10
suma=suma%10
pet=suma//5
suma=suma%5
dva=suma//2
suma=suma%2
jedan=suma//1
suma=suma%1
print(deset,pet,dva,jedan)




#100 CENTI, uraditi i ubaciti u hashtabelu-recnik sa apoenima od 25 10 5 1 

# def loose_change(cents):
#     output_solution={}
#     input_solution={'Pennies':0, 'Nickels':0, 'Dimes':0, 'Quarters':0}
    
#     Pennies=cents//1
#     cents=cents%1
    
#     Nickels=cents//5
#     cents=cents%5
    
#     Dimes=cents//10
#     cents=cents%10
    
#     Quarters=cents//25
#     cents=cents%25
    
#     return loose_change(cents).append(output_solution)

