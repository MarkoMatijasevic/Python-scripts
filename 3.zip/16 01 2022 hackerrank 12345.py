# n = int(input("Enter a number : "))
# for i in range(n):
#     print(i+1,end="")



n = int(input("Unesi broj : "))

for i in range(n):
    print(i*i)