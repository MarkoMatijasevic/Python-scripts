import numpy as np

# Vector
v=np.array([1,3,5,7])
print(v)

# #Matrix -matrica
A= np.mat([[1,2],[3,3]])
jedinicna_matrica=np.mat([[1,0],[0,1]]) # ovo je kao 1-jedinica u mnozenju jer svaki broj puta 1 daje taj broj(5*1=5)
jedinicna_matrica=np.identity
print(A)
print(A+A)
print(A*A)
print(A*jedinicna_matrica)
print(A-A)
print('det(A):', np.linalg.det(A))
print('transpose(A):',np.matrix.transpose(A))


arr=np.arrange(1,5)



import numpy as np

# Vector
v = np.array([1, 3, 5, 7])
print(v)

B = [[1, 2], [3, 3]]
C = []
for i in range(len(B)):
    C.append([])
for vrsta in range(len(B)):
    for i in B[vrsta]:
        C[vrsta].append(i+i)
print(C)

print(B)


# Matrix
A = np.mat([[1, 2], [3, 3]])
print(A)
print(A+A)
print(A*A)
J = np.identity(2)
print(A*J)
print(J*A)

print(np.linalg.det(A))

print(np.matrix.transpose(A))

A = np.mat([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(A)
print('A * A: ', A * A)
print('det(A): ', np.linalg.det(A))
print('transpose(A): ', np.matrix.transpose(A))

arr = np.arange(1,5)
print(arr)

arr = np.array([1,2,3,4,5])
print(arr)
arr = np.array([1.,2,3,4,5])
print(arr)

arr = np.array([0,2,3,4,5],dtype=np.bool)
print(arr)
print(arr*2) # mnozi svaki element iz matrice sa brojem 2
print(arr+2) # dodaje 2 na svaki broj iz liste
print(np.array([1,2,3])+np.array([2,3,4]) # sabira dve matrice
print(matricaA*matricaB) # mnozi svaki sa svakim ( elemement iz matrice)












#ovo je primer kako se to radi kroz dve petlje, jedna ide kroz vrste druga kroz kolone ( imam ovo sacuvano u posebnom fajl programu)
# matt=[[1,2], [3,3]]
# result= []
# for i in matt:
#     r=[]
#     for j in i:
#         r.append(j+j)
#     result.append(r)
# print(result)