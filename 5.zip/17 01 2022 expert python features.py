print(37%2)

print(37//2)

print(37/2)