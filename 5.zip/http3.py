import urllib.request

fhand = urllib.request.urlopen('http://data.pr4e.org/romeo.txt')
for line in fhand:
    print(line.decode().strip())
    

fhand = open('romeo.txt')
for linija in fhand:
    print(linija.strip())