def hanojske_kule(n,a,b,c):
    if(n>0):
        hanojske_kule(n-1,a,c,b)
        print (a,b)
        hanojske_kule(n-1,c,b,a)
    
n=3
a=1
b=3
c=2


hanojske_kule(3,1,3,2)

