import threading  
import time 
  
obj1= threading.Condition() 


def task (): 
  obj1.acquire() 
  #print('addition of 1 to 10000000 ') 
  global add
  #add= 0
  for i in range ( 1 , 1000001 ): 
    add = add+1 
  #print(add) 
  obj1.release() 
  #print('the condition object is releases now') 
    
add=0
time.sleep(1)
t1 = threading.Thread(target = task) 
t2 = threading.Thread(target = task) 
t1.start() 
t2.start() 
t1.join() 
t2.join() 
print(add)