#PRVA OPCIJA ZA RESENJE
# def pretvori(n):
#     string_od_broja=str(n)
#     lista = []
#     for char in string_od_broja:
#         lista.append(char)
#     lista.sort()
#     return int("".join(x for x in lista[::-1]))
# n=42145
# print(pretvori(n))



#DRUGA OPCIJA ZA RESENJE
# def pretvori(n):
#     string_od_broja=str(n)
#     lista = [char for char in string_od_broja]
#     lista.sort()
#     return int("".join(x for x in lista[::-1]))
# n=42145
# print(pretvori(n))


#DA VRATI REZULTAT UNAZAD ALI KAO ARRAY,LISTU, NIZ
# n=42145
# def pretvori(n):
#     lista=[]
#     while(n>0):
#         lista.append(n%10)
#         n=n//10
#     lista.sort()
#     lista.reverse()
#     print(lista)
# pretvori(n)



#DA VRATI REZULTAT KAO INTEGER
# n=42145
# def pretvori(n):
#     lista=[]
#     while(n>0):
#         lista.append(n%10)
#         n=n//10
#     lista.sort(reverse=True)
#     broj=0
#     for br in lista:
#         broj = 10*broj+br
#     return broj
# print(pretvori(n))


#JOS JEDNA OPCIJA DA VRATI KAO INTEGER
# n=42145
# def pretvori(n):
#     x=str(n)
#     y="".join([i+"," for i in x])
#     print(y)
#     lista=y.split(",")
#     print (lista)
#     lista.sort(reverse=True)
#     print(lista)
#     return(int("".join([i for i in lista])))
# print(pretvori(n))






