import operator
from ast import literal_eval

math_operators = {'+': operator.add, '-': operator.sub, 
                  '*': operator.mul, '/': operator.truediv}


def calc(expr):
    tokens = expr.split()
    res = []
    for t in tokens:
        if t in math_operators:
            res[-2:] = [math_operators[t](res[-2], res[-1])]
        else:
            res.append(literal_eval(t))

    return res[0] if res else 0

exp = '5 1 2 + 4 * + 3 -'
print(calc(exp))   # answer is 14