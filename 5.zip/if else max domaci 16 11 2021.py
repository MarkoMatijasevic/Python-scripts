a=int(input("Unesi A="))
b=int(input("Unesi B="))
c=int(input("Unesi C="))
if(a>=b):
    if(a>=c):
        max=a
    else:
        max=c
else:
    if(b>=c):
        max=b
    else:
        max=c
print("MAXIMUM JE = ",max)