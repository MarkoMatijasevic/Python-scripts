# #find the missing number in list A
def getMissingNo(A):
    n = len(A)-1
    total = (n + 1)*(n + 2)/2
    sum_of_A = sum(A)
    return total - sum_of_A
 
 
# Driver program to test the above function
A = [9,2,4,5,7,0,8,6,1]
miss = getMissingNo(A)
print(miss)

