def order2(sentence):
  dict={}
  lista = sentence.split()
  for rec in lista:
      for i in range(len(rec)):
          if(rec[i].isdigit()):
              dict[rec[i]]=rec
  print(dict)
  izlaz=""
  for i in sorted(dict.keys()):
      izlaz+=(dict[i]+" ")
  return izlaz.strip()

s="4of Fo1r pe6ople g3ood th5e the2"
print(order2(s))

print("-------------------")