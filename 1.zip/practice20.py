
for i in range(1,9):
    for j in range(1,9):
        print(".",end=" ")
    print()

