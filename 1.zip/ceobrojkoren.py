# import math
# print(math.sqrt(25))


import math

def is_square(n):
    if n<=0:
        return False
    result = math.sqrt(n) 
    if (result*10)%10==0: # ovo proverava da li je rezultat ceo broj, da nije decimala
        return True
    else:
        return False


print(is_square(144))