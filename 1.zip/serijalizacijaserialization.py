import pickle
 
# A test object
test_dict = {"Hello": "World!"}
 
# Serialization
with open("test.pickle", "wb") as outfile:
    pickle.dump(test_dict, outfile)
print("Written object", test_dict)
 
# Deserialization
with open("test.pickle", "rb") as infile:
    test_dict_reconstructed = pickle.load(infile)
print("Reconstructed object", test_dict_reconstructed)
 
if test_dict == test_dict_reconstructed:
    print("Reconstruction success")
    
test_dict_ba = pickle.dumps(test_dict) 

print(test_dict_ba)

test_dict_reconstructed_ba = pickle.loads(test_dict_ba)

print(test_dict_reconstructed_ba)

 
class NewClass:
    def __init__(self, data):
        print(data)
        self.data = data
 
# Create an object of NewClass
new_class = NewClass(1)
 
# Serialize and deserialize
pickled_data = pickle.dumps(new_class)

# print(pickled_data.data) #AttributeError: 'bytes' object has no attribute 'data'

reconstructed = pickle.loads(pickled_data)
 
# Verify
print("Data from reconstructed object:", reconstructed.data)


# serijalizacija funkcije
 
def test():
    return "Hello world!"
 
# Serialize and deserialize
pickled_function = pickle.dumps(test)
reconstructed_function = pickle.loads(pickled_function)
 
# Verify
print (reconstructed_function()) #prints “Hello, world!”