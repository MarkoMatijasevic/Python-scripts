#  
# def stray(arr):
#     for i in arr:
#         if arr.count(i)==1:
#             return i

# da li se ponavlja n puta, da je n broj ponavljanja neparan broj(odd)
# def find_it(seq):
    # for i in seq:
    #     if seq.count(i)%2!=0:
    #         return i


#def stray(arr):
#     prvalista=[]
#     for i in arr:
#         if i not in prvalista:
#             prvalista.append(i)
#     return(prvalista)



# def stray(arr):
#     prvi_broj = arr[0]

#     for i in arr[1:]:
#         if i<=prvi_broj:
#             return prvi_broj
#         if i>=prvi_broj:
#             return i  
        


        




          
print(stray([1, 1, 1, 1, 1, 1,2]))#2
print(stray([2, 3, 2, 2, 2]))#3
print(stray([3, 2, 2, 2, 2]))#3


