n = 357
while(n>0):
    print(n%10,end="")
    n=n//10

print(n)


