# resenje koje radi ali memorijski ne prihvata Codewars

def page_digits(Page):
    count=0
    for i in range(1,Page+1):
        count += len(str(i))
    return count

print(page_digits(100))



#resenje koje je prihvatio Codewars

# def count_digits(page_number):
#     count=0
#     cek=1
#     for i in range (1,page_number+1):
#         if i%10==0:
#             cek+=1
#         count+=cek
#     return count

# print(count_digits(100))