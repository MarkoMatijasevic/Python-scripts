
def delete_nth ( order, max_e):
    data={}
    result=[]
    for i in order:
        if i not in data:
            data[i]=1
            result.append(i)
        elif (i in data and data[i] <max_e):
            data[i]+=1
            result.append(i)
    return result

print(delete_nth([1,2,2,3,3,4,4,4,4,5,6], 2))



#  lista = [1,2,3,1,4,3] #OVO NIJE DOBRO ALI SAM OSTAVIO KOD
# n=3
# finalna_lista=[]
# def funkcija(lista,n):
#     brojac_lista = dict((i, lista.count(i)) for i in lista)
#     print(brojac_lista)
#     for i in brojac_lista:
#         if brojac_lista[i] > n:
#             finalna_lista.append(i)


# print (funkcija ([1,2,3,1,4,3],1))
# print(finalna_lista)





# def funkcija(lista,pojava):
#     izlaz = [0]*10
#     noviniz=[]
#     for i in range (len(lista)):
#         izlaz[lista[i]]+=1
#         if(izlaz[lista[i]]<=2):
#             noviniz.append(lista[i])
#     return noviniz
# print (funkcija([1,1,3,3,7,1,1,2,2,2,2],2))



# def delete_nth ( order, max_e):
#     data={}
#     result=[]
#     for i in order:
#         if i not in data:
#             data[i]=1
#             result.append(i)
#         elif (i in data and data[i] <max_e):
#             data[i]+=1
#             result.append(i)
#     return result

# print(delete_nth([1,2,2,3,3,4,4,4,4,5,6], 2))