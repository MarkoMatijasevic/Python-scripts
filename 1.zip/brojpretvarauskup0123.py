def generate_integers(n):
    list=[]
    for i in range(0,n+1):
            list.append(i)
            
        
            
    return list


print(generate_integers(12))
