import pandas
from sklearn import model_selection
from sklearn import preprocessing
from sklearn import neighbors
import matplotlib.pyplot as plot


#Euklidsko rastojanje

from sklearn.metrics.pairwise import euclidean_distances

points = [[2, 3], [3, 7], [1, 6]]
print('Question 1: ', euclidean_distances([[4, 4]], points))
print('\n')
print('Question 2: ', euclidean_distances(points))


employees = [
 [20, 50000, 0],
 [24, 45000, 0],
 [32, 48000, 0],
 [24, 55000, 0],
 [40, 50000, 0],
 [40, 62000, 1],
 [40, 48000, 1],
 [32, 55000, 1],
 [40, 72000, 1],
 [32, 60000, 1]
]
scaled_employees = preprocessing.MinMaxScaler(
feature_range=(0,1)).fit_transform(employees)

[
 plot.scatter(x[0], x[1], color = 'g' if x[2] > 0.5 else 'r')
 for x in scaled_employees
] + [plot.scatter(0.5, 0.25925925925925924, color='b')]

scaled_employee_features = scaled_employees.transpose()[:2].transpose()
print(scaled_employee_features)

print('Rastojanje: ', euclidean_distances([[0.5, 0.25925925925925924]], scaled_employee_features))
plot.show()

