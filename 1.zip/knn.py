import pandas
from sklearn import model_selection
from sklearn import preprocessing
from sklearn import neighbors
import matplotlib.pyplot as plot


#Euklidsko rastojanje

from sklearn.metrics.pairwise import euclidean_distances

points = [[2, 3], [3, 7], [1, 6]]
print('Question 1:\n ', euclidean_distances([[4, 4]], points))
print('\n')
print('Question 2:\n ', euclidean_distances(points))