a = [2,5,7,9,10,15,17]
zbir=15
dict ={}
for i in a:
    complement = zbir - i # komplement je dopuna, razlika izmedju npr 15-5 = 10
    if (i in dict.values()):
        print(i, " ", complement)
        break
    dict[i] = complement
    print(dict)





