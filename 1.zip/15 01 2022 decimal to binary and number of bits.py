
def countBits(n):
    return bin(n).count("1")
print(countBits(151))


#n = int(input("Please enter a number : "))
#Ovde ne pretvara dobro i binarni broj, proveriti funkciju, kalkulator binarnih brojeva izbaciju drugaciji broj
# def DecimalToBinary(n):
#     if n >= 1:
#         DecimalToBinary(n // 2)
#     print(n % 2, end = '')

# print("Binary form of that number is :"),DecimalToBinary(n)

# def  countSetBits(n):
#     count = 0
#     while (n):
#         count += n & 1
#         n >>= 1
#     return count
# print("\n""Set of bits in binary form of this number is : "), print(countSetBits(n))

def countBits(n):
    binary=bin(n)
    return len(binary)

a=65
b=183
print(f"Total bits in {a} : {countBits(a)}")
print(f"Total bits in {b} : {countBits(b)}")

