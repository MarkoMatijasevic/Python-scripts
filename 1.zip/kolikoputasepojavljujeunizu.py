lista = [1,1,3,3,7,1,1,2,2,2,2]
pojava = 3
izlaz = [0]*10
print(izlaz)
for i in range(len(lista)):
    izlaz[lista[i]]+=1
print(izlaz)
 
 
 
 
 
 
# def napraviNoviNiz(lista,pojava):
#     pojavljivanja = [0]*10
#     noviNiz = []
#     for i in range(len(lista)):
#         pojavljivanja[lista[i]]+=1
#         if(pojavljivanja[lista[i]]<=3):
#             noviNiz.append(lista[i])
 
#     return noviNiz
 
# print(napraviNoviNiz(lista,pojava))
