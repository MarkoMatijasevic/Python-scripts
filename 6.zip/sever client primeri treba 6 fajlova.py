Vraca zbir
 
Klijent:
 
import socket
 
cSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
cSocket.connect(("localhost",8005))
firstNum = input(cSocket.recv(256).decode("utf-8"))
cSocket.send(bytes(firstNum,"utf-8"))
secondNum = input(cSocket.recv(256).decode("utf-8"))
cSocket.send(bytes(secondNum,"utf-8"))
print("Result is: ", cSocket.recv(256).decode("utf-8"))
 
Server:
 
import socket
 
sServer = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
sServer.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
sServer.bind(("localhost",8005))
sServer.listen()
client,addr = sServer.accept()
client.send(b"Enter number 1: ")
firstNumber = int(client.recv(32).decode("utf-8"))
client.send(b"Enter number 2: ")
secondNumber = int(client.recv(32).decode("utf-8"))
res = format(firstNumber + secondNumber)
client.send(bytes(res,"utf-8"))
 
-------------
 
Pogodak
 
Klijent:
 
import socket
 
playerSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
playerSocket.connect(("localhost",8005))
playerSocket.send(bytes(input("Enter number: "),"utf-8"))
print(playerSocket.recv(128).decode("utf-8"))
 
Server:
 
import socket
import random
 
sSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
sSocket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
sSocket.bind(("localhost",8005))
sSocket.listen()
userSocket,addr = sSocket.accept()
 
playernumber    = int(userSocket.recv(128).decode("utf-8"))
compnumber      = random.randint(1,5)
 
if playernumber == compnumber:
    userSocket.send(b"Nice! I guessed that number")
else:
    userSocket.send(f"Wrong! I guessed {compnumber} and you typed {playernumber}".encode("utf-8"))
 
---------
 
UDP klijent:
 
import socket
 
client = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
client.connect(("localhost",8005))
client.send(b"Hello world")
 
UDP server:
 
import socket
 
server = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
server.bind(("localhost",8005))
msg = server.recvfrom(16)
print(msg)

RAW Paste Data


Vraca zbir

Klijent:

import socket

cSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
cSocket.connect(("localhost",8005))
firstNum = input(cSocket.recv(256).decode("utf-8"))
cSocket.send(bytes(firstNum,"utf-8"))
secondNum = input(cSocket.recv(256).decode("utf-8"))
cSocket.send(bytes(secondNum,"utf-8"))
print("Result is: ", cSocket.recv(256).decode("utf-8"))

Server:

import socket

sServer = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
sServer.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
sServer.bind(("localhost",8005))
sServer.listen()
client,addr = sServer.accept()
client.send(b"Enter number 1: ")
firstNumber = int(client.recv(32).decode("utf-8"))
client.send(b"Enter number 2: ")
secondNumber = int(client.recv(32).decode("utf-8"))
res = format(firstNumber + secondNumber)
client.send(bytes(res,"utf-8"))

-------------

Pogodak

Klijent:

import socket

playerSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
playerSocket.connect(("localhost",8005))
playerSocket.send(bytes(input("Enter number: "),"utf-8"))
print(playerSocket.recv(128).decode("utf-8"))

Server:

import socket
import random

sSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
sSocket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
sSocket.bind(("localhost",8005))
sSocket.listen()
userSocket,addr = sSocket.accept()

playernumber    = int(userSocket.recv(128).decode("utf-8"))
compnumber      = random.randint(1,5)

if playernumber == compnumber:
    userSocket.send(b"Nice! I guessed that number")
else:
    userSocket.send(f"Wrong! I guessed {compnumber} and you typed {playernumber}".encode("utf-8"))
	
---------

UDP klijent:

import socket

client = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
client.connect(("localhost",8005))
client.send(b"Hello world")

UDP server:

import socket

server = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
server.bind(("localhost",8005))
msg = server.recvfrom(16)
print(msg)
