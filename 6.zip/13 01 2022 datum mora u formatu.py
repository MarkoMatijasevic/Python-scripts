
#format datuma mora da bude 13.05.2022, 13-05-2022, 13.05.22, 13-05-22, 1-5-2022, 1-05-2022

import re
pattern = re.compile("^([0?[1-9]] | [1-2][0-9] | 3[0-1]])$")
unos= input("Enter date: ")
print(pattern.search(unos))
