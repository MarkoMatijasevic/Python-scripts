#ispisuje brojeve iz skupa po rastucoj vrednosti, od manjeg ga vecem

a=[5,2,9,1,7]
print(a)
for i in range(0,len(a)-1):
    for j in range(i+1,len(a)):
        if (a[i]>a[j]):
            pom=a[i]
            a[i]=a[j]
            a[j]=pom
print(a)

#ispisuje brojeve skupa po opadajucoj vrednosti, od veceg prema manjem (promenjen samo znak < u 18 redu)
a=[5,2,9,1,7]
print(a)
for i in range(0,len(a)-1):
    for j in range(i+1,len(a)):
        if (a[i]<a[j]):
            pom=a[i]
            a[i]=a[j]
            a[j]=pom
print(a)

mat=[[1,2,5,7],[3,4,9,2],[0,1,0,1]]
for i in range(len(mat)):
    for j in range(len(mat[i])):
        print(mat[i][j], end="  ")
    print()

#drugi nacin da se uradi zadatak iznad
mat=[[1,2,5,7],[3,4,9,2],[0,1,0,1]]
for i in mat:
    for j in i:
        print(j,end=" ")
    print()




#PODPROGRAM U PYTHON-u je FUNKCIJA f(x) kao u matematici
a=3
b=4
c=a+b
print(c)

def imePodprograma(): #podprogram, uvek ide () na kraju podprograma.
    imePodprograma() # poziv podprograma
    print(ABV)#telo podprograma


#PRIMER:

def zbir(a,b):
    print (a+b)

zbir(5,4)





def faktorijal(n):
    p=1
    for i in range(2,n+1):
        p*=i
    print(p)
    return(p)





faktorijal(5)


