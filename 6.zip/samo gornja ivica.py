sirina=10
visina=5
for i in range(visina):
    for j in range(sirina):
        if(i==0):
            print("+",end="")
        else:
            print("-",end="")
    print()