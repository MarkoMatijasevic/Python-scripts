from Student import Student 

student1= Student("Jim", "Business", 3.1, False)
student2= Student("Pam", "Art", 2.5, True)
print (student1.name)
print (student2.major)


