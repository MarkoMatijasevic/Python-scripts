
import pandas as pd
import os


dataset = pd.read_excel ( "TSF top accounts.xlsx")

print(dataset)





