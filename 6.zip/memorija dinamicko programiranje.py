n=900
memorija=[0]*(n-1)
print(memorija)
def fibrek(n):
    if(memorija[n]!=0):
        return memorija[n]

    if(n<=1):
        return n
    memorija[n]=fibrek(n-1)+fibrek(n-2)
    return memorija[n]

print(fibrek(900))
