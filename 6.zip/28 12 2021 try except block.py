

#sa codecamp youtube kanala:
# try:
#     answer = 10/0
#     number = int(input("Enter a number : "))
#     print (number)
# except ZeroDivisionError:
#     print("Divided by zero")
# except ValueError :
#     print("Invalid Input")


#sa predavanja IT akademija
# try:

# except:

# else:

# finally:obicno za zatvaranje resursa





