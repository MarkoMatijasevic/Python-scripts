import useful_tools

print (useful_tools.roll_dice(10))


#importovali smo python file koji se zove useful_tools koji sam prethodno napravio i sacuvao u istom folderu.
#ovako se importuju moduli koji mogu da se importuju sa weba i programa koji je neko vec napisao
# kucas na google samo list of python modules


# PIP je package manager, preko njega instaliram module, eksterne module, sve module.
# kucas u cmd terminalu : pip install naziv python modula, ili uninstall ako treba