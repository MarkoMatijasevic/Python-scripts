# class Dog ():
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age  

#     def speak(self):
#         print('Hi I am', self.name, 'and I am', self.age, 'years old')


# tim=Dog('Tim',5)
# fred=Dog('Fred',6)
# tim.speak()
# fred.speak()







# class Dog():
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age
    
#     def speak (self):
#         print ('Hi, I am', self.name,'and I am', self.age, 'years old')


# class Cat(Dog):
#     def __init__(self, name, age,color):
#         super().__init__(name, age)
#         self.color=color

#     def talk (self):
#         print ('Meow')


# Fred = Cat('Fred',5,'Yellow')
# Fred.speak()




# class Vehicle():
#     def __init__(self, price, gas, color):
#         self.price=price
#         self.gas=gas
#         self.color=color

#     def fillUpTank(self):
#         self.gas=100
    
#     def emptyTank(self):
#         self.gas=0
    
#     def gasLeft(self):
#         return self.gas
    
# class Car(Vehicle):
#     def __init__(self, price, gas, color, speed):
#         super().__init__(price, gas, color)
#         self.speed=speed

#     def beep(self):
#         print('Beep Beep')



# class Truck (Vehicle):
#     def __init__(self, price, gas, color, tires):
#         super().__init__(price, gas, color)
#         self.tires=tires

#     def beep(self):
#         print('Honk Honk') 



# Ferrari = Car('350.000 EUR','90 liters','Red', '300km/h')
# Ferrari.beep()

# Scania = Truck("400.000 EUR", '1500 liters', 'Grey','150 km/h')
# Scania.beep()

# class Dog:
#     dogs=[]

#     def __init__(self,name):
#         self.name=name
#         self.dogs.append(self)

#     @classmethod
#     def num_dogs(cls):
#         return len(cls.dogs)

#     @staticmethod
#     def bark(n):
#         """ barks n times"""
#         for _ in range(n):
#             print("Bark!")

# Dog.bark(5)

