
#format e-mail adrese mora da bude marko.matijasevic@gmail.com

import re
pattern = re.compile("^([a-zA-Z]\w{1,}[. | _ | -]?[a-zA-Z]\w{1,}@[a-zA-Z]{2,}\.[a-zA-Z]{2,4})$")
unos= input("Enter mail: ")
print(pattern.search(unos))