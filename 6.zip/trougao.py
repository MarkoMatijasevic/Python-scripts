sirina=20
for i in range(sirina):
    for j in range(sirina):
        if(j<=i):
            print("*",end="  ")
    print()
    