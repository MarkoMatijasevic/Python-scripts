#from Chef import Chef
from ChineeseChef import ChineeseChef

myChef = Chef()

myChef.make_fried_rice()
myChineeseChef = ChineeseChef()
myChineeseChef.make_fried_rice()
