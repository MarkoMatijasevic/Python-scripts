import collections
from collections import namedtuple

Point = namedtuple('Point', {'x':0, 'y':0, 'z':0})

newP = Point (3,4,5)
print(newP)



