from audioop import add
import threading
import time
def task ():
    global add
    for i in range (1,10000001):
        add=add+1

add=0
time.sleep(1)

t1 = threading.Thread(target=task)
t2 = threading.Thread(target=task)

t1.start()
t2.start()
print(add)

