
class Osoba:
 
    def __init__(self, ime, prezime, jmbg):
        self.__ime = ime
        self.__prezime = prezime
        self.__jmbg = jmbg
 
    def __str__(self):
        return '{} {} {}'.format(self.__ime, self.__prezime,self.__jmbg)
 
    def predstavi_se(self):
        print('Ja sam', self.__ime, self.__prezime)
 
# predstavlja osobe zaposlene na fakultetu
class Zaposleni(Osoba): # izvodjenje iz klase Osoba
    def __init__(self, ime, prezime, jmbg, plata, soba, telefon):
        super().__init__(ime, prezime, jmbg) # priroda osobe
        self.__plata = plata
        self.__soba = soba
        self.__telefon = telefon
 
    def __str__(self):
        return super().__str__() + '\n' + str(self.__plata) + \
            ' soba: ' + self.__soba + ' tel: ' + self.__telefon
 
    def promeni_platu(self, nova):
        self.__plata = nova
 
# predstavlja studente na fakultetu
 
class Student(Osoba): # izvodjenje iz klase Osoba
    def __init__(self, ime, prezime, jmbg, indeks, smer):
        super().__init__(ime, prezime, jmbg) # priroda osobe
        self.__indeks = indeks
        self.__godina = 1
        self.__smer = smer
 
    def __str__(self):
        return super().__str__() + '\n' + self._indeks + \
            ' godina: ' + str(self.__godina) + ' smer: ' + self.__smer
 
    def upisi_godinu(self, godina):
        if godina < 6 and (godina == self.__godina or # max 5 god
                           godina == self.__godina + 1):
            self.__godina = godina

 

 
z = Zaposleni('Aca', 'Vukic', '12153', 95000, '3a', '4218-589')
s = Student('Mitar', 'Miric', '12131', '119/17', 'MTI')
print(isinstance(s, Student), isinstance(s, Osoba))
print(isinstance(z, Student), isinstance(z, Osoba))
 
z.predstavi_se()
s.predstavi_se()
 
print(z)
