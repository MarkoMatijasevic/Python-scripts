import collections
from collections import deque


d=deque("Hello")
d.append("4")
d.extend("55")
d.extendleft("112")
d.rotate(-2)
d.rotate(1)
print(d)
