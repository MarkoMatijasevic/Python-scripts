from Student1 import Student 


student1= Student("Oscar", "Accounting", 3.1)
student2= Student("Phyllis", "Business", 3.8)

print(student1.on_honor_roll())




