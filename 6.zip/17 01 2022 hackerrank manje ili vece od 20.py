n=int(input("Please enter a number :"))

if n%2== 1 :
    print ("Weird")

if n%2==0 and n>=1 and n<=5:
    print("Not Weird")

if n%2==0 and n>=6 and n<=20:
    print("Weird")
    
if n%2==0 and n>20:
    print("Not Weird")

