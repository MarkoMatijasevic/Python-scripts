
#singleton primer

# class Konekcija:
#     pass

# obj1=Konekcija()
# obj2=Konekcija()

# print(obj1==obj2)
# obj1=obj2

# print(obj1==obj2)


# ovako se resava, tako sto se u klasi MyClass napravi odmah staticka metoda

class MyClass: 
    __instance = None 
    @staticmethod
    def get_instance():
        if not MyClass.__instance:
            MyClass.__instance = MyClass()
        return MyClass.__instance
 
    def __init__(self):
        if not MyClass.__instance:
            MyClass.__instance = self
        else:
            raise Exception("Cannot Instantiate")
 
a = MyClass.get_instance()
b = MyClass.get_instance()
 
print(a == b)


