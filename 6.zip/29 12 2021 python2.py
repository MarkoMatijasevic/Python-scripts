'''a= int(input("Unesite A: "))
b=int(input ("Unesite B: "))
result=(a+b)
print (result)'''

'''moja_lista = ["Marko", 2, "treci element"]
#print(moja_lista[-1],[-2],[-3])
#moja_lista.append("novi_objekat")
moja_lista[0] = ("prvi_element")
moja_lista[1] = ("drugi_element")
moja_lista[2] = ("treci_element")
#for neki_element in moja_lista:
    #print(neki_element)
#print(len(moja_lista))'''

# def oduzimanje (broj_perimetar):
#     return broj_perimetar-1
# print(oduzimanje(7))

# help(str)
# help(int)
# help(bool)
