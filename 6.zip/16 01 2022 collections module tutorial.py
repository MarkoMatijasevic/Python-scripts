
#COLLECTIONS

 #Containers types:
 #1.list
 #2.set
 #3.dict
 #4.tuple - immutable

 #Types
 #1 counter <- this video that we imported above
 #2 deque
 #3 namedTuple()
 #4 orderdDict
 #5 defaultdict


import collections
from collections import Counter

#Example 1
# c = Counter ('gallad')
# print(c)
# c = Counter (['a', 'a', 'b','c','c'])
# print(c)
# c = Counter ({'a':1,"b":2})
# print(c)
# c = Counter (cats=4, dogs=7)
# print(c)


#Example 2
# c = Counter ('gallad')
# print(c)
# c = Counter (['a', 'a', 'b','c','c'])
# print(c)
# c = Counter ({'a':1,"b":2})
# print(c)
# c = Counter (cats=4, dogs=7)
# print(c['cats'])



#Example 3
# c = Counter ('gallad')
# print(c)
# c = Counter (['a', 'a', 'b','c','c'])
# print(c)
# c = Counter ({'a':1,"b":2})
# print(c)
# c = Counter (cats=4, dogs=7)
# print(list(c.elements()))



#Example 4
# c = Counter ('gallad')
# print(c)
# c = Counter (['a', 'a', 'b','c','c'])
# print(c)
# c = Counter ({'a':1,"b":2})
# print(c)
# c = Counter (cats=4, dogs=7)
#c.most_common(2)



#Example 5 subtract
# c= Counter(a=4, b=2,c=0, d=-2)
# d= ['a','b','b','c']
# c.subtract(d)
# print(c)



#Example 6 update
# c= Counter(a=4, b=2,c=0, d=-2)
# d= ['a','b','b','c']
# c.subtract(d)
# print(c)
# c.update(d)
# print(c)



#Example 7 clear
# c= Counter(a=4, b=2,c=0, d=-2)
# d= ['a','b','b','c']
# c.subtract(d)
# print(c)
# c.update(d)
# print(c)
# c.clear()
# print(c)



#Example 8 add, subtract, intersection, union for Counters
# c= Counter(a=4, b=2,c=0, d=-2)
# d= Counter(['a','b','b','c'])
# print(c+d)
# print(c-d)
# print()


#intersection
# c= Counter(a=4, b=2,c=0, d=-2)
# d= Counter(['a','b','b','c'])
# print(c&d) sign "&" is for intersection


#union
# c= Counter(a=4, b=2,c=0, d=-2)
# d= Counter(['a','b','b','c'])
# print(c | d) sign " | " is for union

