todos = open ('todosbin.txt','wb')
todos.write ('Evo upisujem prvi red')
todos.write ('Evo upisujem drugi red')
todos.close()


