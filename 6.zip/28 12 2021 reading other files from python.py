# marko_file = open ("marko.txt", "r")# r kao mode znaci read, w znaci write, 
#a znaci append-dodaj nesto u fajl, r+ znaci reading and changing


# employee_file = open("marko.txt", "r")

# print(employee_file.read())

# employee_file.close()


#ovo je dodalo tekst ispod u fajl marko.txt preko append moda (a) i write opcije dole
employee_file = open("marko.txt", "a")

employee_file.write("\nNovi tekst koji dodajem : U stvari nisam mentol,vec sam pametan covek")

employee_file.close()