todos = open('todos.txt','w')
print ('Evo upisujem prvi red', file=todos)
print ('Evo upisujem drugi red', file = todos)
todos.close()

task = open ('todos.txt', 'r')
for chore in task :
    print (chore,end="")

task.close()

# marko_file = open ("marko.txt", "r")# r kao mode znaci read, w znaci write, 
#a znaci append-dodaj nesto u fajl, r+ znaci reading and changing
# employee_file = open("marko.txt", "r")
# print(employee_file.read())
# employee_file.close()
#ovo je dodalo tekst ispod u fajl marko.txt preko append moda (a) i write opcije dole