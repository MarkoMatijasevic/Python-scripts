#treba pronaci najveci zajednicki delilac NZD, za brojeve 36 i 24, rezultat je 12
#ovo je jedno od resenja, brute force metoda

# a=36
# b=24
# for i in range (2,25):
#     if ( a%i==0 and b%i==0):        ......% procenat je deljenje bez ostatka iliti mod
#         d=i
# print(d)

# razlika izmedju dva broja (36-24=12) uvek mora da deli ta dva broja,  EUKLIDOV ALGORITAM 




#Uslov da je A vece od B
# ovo je iterrativna verzija Euklidovog algoritma

# a=45
# b=10
# while(b>0):
#     pom=a%b
#     a=b
#     b=pom
#     print(a,b)

# print(a)


#Rekurzivno resenje
# def NZD (a,b):
#     if b==0:
#         return a
    
#     return NZD(b,a%b)

# print("Rek", NZD(45,10))



# a=[1,2,3]
# try:
#     print(a[3])
# except:
#     print("Hej nema tog indeksa")
# else:
#     print("Super sve je kako treba")
# finally:
#     print("Ja uvek moram nesto da dodam")




#sa predavanja IT akademija
# try:

# except:

# else:

# finally:obicno za zatvaranje resursa



# x=0

# try:
#     print(5/x)
# except:
#     raise Exception ('Imenilac je 0')

# print("Posle")
 

'''class Card:  
    def __init__(self):
        self.__number    = 0
        self.__color     = ""
        self.__code      = "H1" 

    def get_number(self):
        return self.__number

    @property #geter specijalna metoda 
    def number (self):
        print("Ovo se desilo")
        return self.__number

c= Card()
print(c.number)
print (c.get_number())'''

# ovo je seter
# class Card:  
#     def __init__(self):
#         self.__number    = 0
#         self.__color     = ""
#         self.__code      = "H1"
#     def getNumber(self):
#         return self.__number
#     def setNumber(self,number):
#         self.__number = number
#     @property    
#     def number(self): 
#         print("Ovo se desilo geter")
#         return self.__number
#     @number.setter
#     def number(self,val): 
#         print("Ovo se desilo seter")
#         self.__number = val
# c = Card()
# print(c.number) 
# print(c.getNumber())
# c.setNumber(7)
# print(c.number) 
# c.number = 9
# print(c.number) 



#ponovo except tema
'''x=0
a=[]
try:
   # print(5/x) da se ne desi prvi except Can't divide by zero
    print(a[0])

except ZeroDivisionError:
    print("Can't divide by zero" )

except:
    raise Exception ('Imenilac je 0')

print("Posle")'''





