from Chef import Chef

class ChineeseChef(Chef):
    
    def make_fried_rice(self):
        print (" The chef makes fried rice ")