import logging
import threading
import time

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-10s) %(message)s',
                    )

class MyThread(threading.Thread):

    def run(self):
        time.sleep(2)
        logging.debug('running')
        return

for i in range(5):
    t = MyThread()
    t.start()