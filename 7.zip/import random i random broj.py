import random
a=int(input("Unesi broj "))
moj_broj=random.randint(1,10)
print(moj_broj)
print(a==moj_broj)
a=moj_broj
print(a)
