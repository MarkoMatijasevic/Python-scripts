print("Unesi poluprecnik kruga")
r=int(input("Unesite poluprecnik"))
Pi=3.14
P=r*r*Pi
print(P)
