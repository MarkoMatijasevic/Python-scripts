a=8
b=7
max=a
if(a>b):
    max=a
if(b>a):
    max=b
#if(a==b):
   # max=a
print ("Maksimum je ", max)

