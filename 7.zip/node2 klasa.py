class Node:
    def __init__(self, dataval=None):
        self.dataval = dataval
        self.nextval = None

class SLinkedList:
    def __init__(self):
        self.headval = None
        self.tailval = None

# Print the linked list
    def listprint(self):
        printval = self.headval
        while printval is not None:
            print (printval.dataval,end=" ")
            printval = printval.nextval   
        print("\n--------------")

    # Function to add newnode            
    def AtBegining(self,newdata):
        NewNode = Node(newdata)
        NewNode.nextval = self.headval
        self.headval = NewNode

    def AtEnd(self, newdata):
        NewNode = Node(newdata)
        if(self.headval is None):
            self.headval = NewNode
            return

        last = self.headval
        while(last.nextval is not None):
            last = last.nextval
            print(last.dataval)
        last.nextval = NewNode

    def numberOfElements(self):
        suma = 0
        pom = self.headval
        while(pom is not None):
            suma+=1
            pom = pom.nextval
        return suma

    def sumOfElements(self):
        suma = 0
        pom = self.headval
        while(pom is not None):
            suma+=pom.dataval
            pom = pom.nextval
        return suma
        

if __name__=='__main__':

    llist = SLinkedList()
    llist.AtBegining(2)
    llist.AtBegining(7)
    llist.AtBegining(1)
    llist.AtBegining(4)
    llist.listprint()
    llist.AtEnd(9)
    llist.AtEnd(10)
    llist.AtEnd(11)
    llist.listprint()
    print(llist.numberOfElements())
    print(llist.sumOfElements())
