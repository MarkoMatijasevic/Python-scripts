MaleGender =(" ")
FemaleGender=(" ")
gender = input("Enter your gender (type male or female)?=")
if gender=="male":
    print("You choose male")
    gender = MaleGender
else:
    print("You choose female")
    gender = FemaleGender
age=int(input("Enter your age="))
if age>=70:
    print("Access denied")
else:
    if (FemaleGender and age>=16) or (MaleGender and age>=18): 
        print("Access allowed")
    else:
        print ("Access denied")


    