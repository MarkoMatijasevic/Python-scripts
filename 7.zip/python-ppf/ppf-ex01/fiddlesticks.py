print("Your bidding master!")
