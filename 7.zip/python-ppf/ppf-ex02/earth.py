print("The earth was nearly wiped clean of life.")
 print("A great cleansing, an atomic spark struck by human hands, quickly raged out of control. Spears of nuclear fire rained from the skies.")
print("Continents were swallowed in flames and fell beneath the boiling oceans. Humanity was almost extinguished, their spirits becoming part of the background radiation that blanketed the earth.")