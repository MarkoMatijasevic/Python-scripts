'''
One of the northern tribes claims they are descended from one such Vault. They hold that their founder and ancestor, one known as the "Vault Dweller," once saved the world from a great evil. According to their legend, this evil arose in the far south. It corrupted all it touched, twisting men inside, turning them into beasts. Only through the bravery of this Vault Dweller was the evil destroyed.
But in so doing, he lost many of his friends and suffered greatly, sacrificing much of himself to save the world. When at last he returned to the home he had fought so hard to protect, he was cast out. Exiled. In confronting that which they feared, he had become something else in their eyes...and no longer their champion.
'''
print("Set your appearance")