num = int(input('Enter number? '))
if(num%2 == 0):
    print("Number is even")
else:
    print("Number is odd") 