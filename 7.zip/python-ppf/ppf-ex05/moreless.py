num = int(input('Enter number? '))
if(num<0):
    print("Number is less than zero")
elif(num>0):
    print("Number is higher than zero")
else:
    print("Number is zero")