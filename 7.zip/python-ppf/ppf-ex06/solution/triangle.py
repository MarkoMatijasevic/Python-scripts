H       = 10
a       = 1 
for i in range(H):
    for j in range(a):
        print("*",end="")
    a+=1
    print("")
