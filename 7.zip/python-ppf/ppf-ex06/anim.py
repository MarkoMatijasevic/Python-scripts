
target  = 50
#Your code here