a = [3,7,1,9,2,4,5,12]
odd = []
even = []
#Your code here