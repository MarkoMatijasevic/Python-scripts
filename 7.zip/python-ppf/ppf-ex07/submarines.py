m           = 10
submarines  = [3,5,3,6,7,6,8,6,2,1,2,2] 
#Your code here

