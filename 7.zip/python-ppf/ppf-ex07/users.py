blacklist = ["peter","john","sally"]
users = []
#Your code here