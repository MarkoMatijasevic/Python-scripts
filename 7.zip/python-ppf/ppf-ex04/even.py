print("Enter number?")
num = int(input())
is_even = (num % 2) == 0
print("Number is even: ",is_even)