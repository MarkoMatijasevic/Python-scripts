eur = 1.3
usd = 1.1 
val = float(input("Enter value: ")) 
total_euro      = "Total Euro: %.2f" % (val/eur)
total_dollar    = "Total Dollars: %.2f" % (val/usd)
print(total_euro)
print(total_dollar)