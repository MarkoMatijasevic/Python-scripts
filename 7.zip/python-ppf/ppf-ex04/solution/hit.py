proj_x      = 0
wall_x      = 7
proj_spd    = 2

print("Hit: ", proj_x > wall_x)
proj_x+=proj_spd
print("Hit: ", proj_x > wall_x)
proj_x+=proj_spd
print("Hit: ", proj_x > wall_x)
proj_x+=proj_spd
print("Hit: ", proj_x > wall_x)
proj_x+=proj_spd
print("Hit: ", proj_x > wall_x)
proj_x+=proj_spd