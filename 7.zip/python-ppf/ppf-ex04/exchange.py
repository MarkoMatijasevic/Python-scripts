eur = 1.3
usd = 1.1
#Your code here