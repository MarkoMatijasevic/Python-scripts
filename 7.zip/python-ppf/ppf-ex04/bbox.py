x       = 5
y       = 6
width   = 5
height  = 4
#Your code here