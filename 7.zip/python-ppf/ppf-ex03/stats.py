hero_name   = "Luke"
health      = 150
mana        = 40
xp          = 200
level       = 5  

print("Hero stats: ")
print("#########################")
print("Name: ")
print(hero_name)
print("Health: ")
print(health)
print("Mana: ")
print(mana)
print("XP: ")
print(xp)
print("Level: ")
print(level)