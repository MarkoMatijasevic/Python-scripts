flight_code     = "J123"
plane_name      = "Boeing 777"
latitude        = -149.492362
longitude       = 64.201618
alititude       = 2547 

print("Flight information: ")
print("#########################")
print("Flight code: ", flight_code) 
print("Airplane name: ", plane_name) 
print("Latitude: ", latitude) 
print("Longitude: ", longitude) 