manufacturer    = "Apple"
model_name      = "iPhone 8"
price           = 300
image           = "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone8-select-2019-family?wid=441&amp;hei=529&amp;fmt=jpeg&amp;qlt=95&amp;op_usm=0.5,0.5&amp;.v=1550795431127"

print("Mobile phone:")
print("Manufacturer: ") 
print(manufacturer) 
print("Model: ") 
print(model_name) 
print("Price: ") 
print(price)
print("Image: ") 
print(image)  