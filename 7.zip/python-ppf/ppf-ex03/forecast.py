city = "Juneau"
temperature = 2.5
rain = False
pressure = 998

print("Forecast for:")
print(city)
print("Temperature: ")
print(temperature)
print("Will rain: ")
print(rain)
print("Pressure: ")
print(pressure) 