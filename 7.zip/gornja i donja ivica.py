sirina=10
visina=5
for i in range(visina):
    for j in range(sirina):
        if(i==0 or i==visina-1 or j==0 or j==sirina+1):
            print("#",end="")
        else:
            print("#",end="")
    print()