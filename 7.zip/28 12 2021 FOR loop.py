
# friends = ["Jim","Karen","Kevin"] za niz moze ovako da se uradi, opcija 1
# for friend in friends:
#     print(friend)


# friends = ["Jim","Karen","Kevin"] za niz moze i ovako da se uradi, opcija 2
# for name in friends:
#     print(name)


# for letter in "Giraffe Academy": za string moze ovako da se uradi
#     print(letter)


# for index in range(10): za integer broj moze ovako da se uradi,ispisuje sve brojeve od 0 do 9, 10 ne ispisuje
#     print(index)

# for index in range(3,13): ovde ispisuje od 3 do 12
#     print (index)

# friends = ["Jim","Karen","Kevin"] ovde ispisuje celu duzinu niza(array) koji se zove friends, jedan po jedan
# for index in range (len(friends)):
#     print(friends[index])
