class Tacka:

    br_Tacaka=0
    t_kretanja=None

    def __init__(self, x=0, y=0):
        self.__x = x
        self.__y = y
        Tacka.br_Tacaka +=1


    def napisi(self):
        print(self.__x,self.__y)


t1= Tacka()
t2= Tacka(5)
t3= Tacka(2,3)

t1.napisi()
t2.napisi()
t3.napisi()