
age= int(input("Enter your age"))
if age>70 :
    print("Access denied")
else :
    if gender == m > 18:
        print("Access allowed")
    else:
        print ("Access denied")
if gender==f >16:
    print("Access allowed")
else:
    print("Access denied")
