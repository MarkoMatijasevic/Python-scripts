
# definiše apstraktni tip koji predstavlja vlasnike stanova
class Vlasnik:
 
    def __init__(self, ime, prezime, jmbg):
        self.__ime = ime
        self.__prezime = prezime
        self.__jmbg = jmbg
 
    def __str__(self):
        return '{} {} {}'.format(self.__ime,self.__prezime, self.__jmbg)
 
    def jmbg(self):
        return self.__jmbg
 
# da li ime ili prezime sadrži kljucnu rec
    def ime_sadrzi(self, upit):
        ime_ok = self.__ime.find(upit) != -1
        prezime_ok = self.__prezime.find(upit) != -1
        return ime_ok or prezime_ok
 
 # ostale metode ....
 
# definiše tip koji predstavlja stanove
class Stan:
 
    def __init__(self, m2, sprat):
        self.__m2 = m2
        self.__sprat = sprat
        self.__vlasnik = None
 
    def __str__(self):
         st = '{}m2 spr. {}'.format(self.__m2, self.__sprat)
         return '{}. {}'.format(st, str(self.__vlasnik))
 
    def vlasnik(self):
        return self.__vlasnik
 
    def promeni_vlasnika(self, novi_vlasnik):
        self.__vlasnik = novi_vlasnik
 
    def površina(self):
        return self.__m2
 
 # ostale metode ....
 
 # definiše apstraktni tip koji predstavlja stambenu zgradu
 
class Zgrada:
 
    def __init__(self, adresa, stanovi):
        self.__adresa = adresa
        self.__stanovi = stanovi
 
    def __str__(self):
        opis = []
        for stan in self.__stanovi:
            opis.append(str(stan))
        return '{}\n---\n{}\n---\n'.format(self.__adresa, opis)
 
    def dodaj_stan(self, stan):
        self.__stanovi.append(stan)
 
# vraca recnik sa vlasnicima koji zadovoljavaju upit
# i njihovim stanovima
    def stanovi_vlasnika(self, upit):
        vlasnik_stanovi = {} # recnik sa stanovima po vlasniku
        for stan in self.__stanovi:
            v = stan.vlasnik()
            if v != None and v.ime_sadrzi(upit):
                v_stanovi = vlasnik_stanovi.get(v.jmbg(), []) 
                # get vraca [] ako key ne postoji
                v_stanovi.append(stan)
                vlasnik_stanovi[v.jmbg()] = v_stanovi
        return vlasnik_stanovi
 
# ostale metode ....
 
 

 
# Kreira tri vlasnika
raja = Vlasnik('Raja', 'Patakovic', '123456')
gaja = Vlasnik('Gaja', 'Patakovic', '123457')
vlada = Vlasnik('Vladimir', 'Putinic', '123458')
 
# Kreira cetiri stana u zgradi P+1
s0_1 = Stan(50, 0) # sprat 0 je prizemlje
s0_2 = Stan(100, 0)
s1_1 = Stan(75, 1)
s1_2 = Stan(75, 1)
zgrada = Zgrada('Radnicka 4', [s0_1, s0_2, s1_1, s1_2])
 
# Posle kupovine stanova
 
s0_1.promeni_vlasnika(raja)
s0_2.promeni_vlasnika(gaja)
s1_1.promeni_vlasnika(vlada)
s1_2.promeni_vlasnika(raja) # opet Raja
 
# Posle velikog interesovanja ide nadgradnja
s2_1 = Stan(150, 2)
zgrada.dodaj_stan(s2_1)
 
# Ispis podataka o zgradi
print(zgrada)
 
# Vlasnici u zgradi koji u imenu imaju 'aja'
print('Vlasnici sa "aja" u imenu:\n')
for stanovi in zgrada.stanovi_vlasnika('aja').values():
    total = 0
    for stan in stanovi:
        total += stan.površina()
    #print(stan)
print(stan.vlasnik())
print('Ukupno', total, 'm2\n')


# definiše apstraktni tip koji predstavlja vlasnike stanova
class Vlasnik:

    def __init__(self, ime, prezime, jmbg):
        self.__ime = ime
        self.__prezime = prezime
        self.__jmbg = jmbg

    def __str__(self):
        return '{} {} {}'.format(self.__ime,self.__prezime, self.__jmbg)
   
    def jmbg(self):
        return self.__jmbg

# da li ime ili prezime sadrži kljucnu rec
    def ime_sadrzi(self, upit):
        ime_ok = self.__ime.find(upit) != -1
        prezime_ok = self.__prezime.find(upit) != -1
        return ime_ok or prezime_ok

 # ostale metode ....

# definiše tip koji predstavlja stanove
class Stan:

    def __init__(self, m2, sprat):
        self.__m2 = m2
        self.__sprat = sprat
        self.__vlasnik = None

    def __str__(self):
         st = '{}m2 spr. {}'.format(self.__m2, self.__sprat)
         return '{}. {}'.format(st, str(self.__vlasnik))

    def vlasnik(self):
        return self.__vlasnik

    def promeni_vlasnika(self, novi_vlasnik):
        self.__vlasnik = novi_vlasnik

    def površina(self):
        return self.__m2

 # ostale metode ....

 # definiše apstraktni tip koji predstavlja stambenu zgradu

class Zgrada:

    def __init__(self, adresa, stanovi):
        self.__adresa = adresa
        self.__stanovi = stanovi

    def __str__(self):
        opis = []
        for stan in self.__stanovi:
            opis.append(str(stan))
        return '{}\n---\n{}\n---\n'.format(self.__adresa, opis)

    def dodaj_stan(self, stan):
        self.__stanovi.append(stan)

# vraca recnik sa vlasnicima koji zadovoljavaju upit
# i njihovim stanovima
    def stanovi_vlasnika(self, upit):
        vlasnik_stanovi = {} # recnik sa stanovima po vlasniku
        for stan in self.__stanovi:
            v = stan.vlasnik()
            if v != None and v.ime_sadrzi(upit):
                v_stanovi = vlasnik_stanovi.get(v.jmbg(), []) 
                # get vraca [] ako key ne postoji
                v_stanovi.append(stan)
                vlasnik_stanovi[v.jmbg()] = v_stanovi
        return vlasnik_stanovi

# ostale metode ....




# Kreira tri vlasnika
raja = Vlasnik('Raja', 'Patakovic', '123456')
gaja = Vlasnik('Gaja', 'Patakovic', '123457')
vlada =Vlasnik('Vladimir', 'Putinic', '123458')

# Kreira cetiri stana u zgradi P+1
s0_1 = Stan(50, 0) # sprat 0 je prizemlje
s0_2 = Stan(100, 0)
s1_1 = Stan(75, 1)
s1_2 = Stan(75, 1)
zgrada = Zgrada('Radnicka 4', [s0_1, s0_2, s1_1, s1_2])

# Posle kupovine stanova

s0_1.promeni_vlasnika(raja)
s0_2.promeni_vlasnika(gaja)
s1_1.promeni_vlasnika(vlada)
s1_2.promeni_vlasnika(raja) # opet Raja

# Posle velikog interesovanja ide nadgradnja
s2_1 = Stan(150, 2)
zgrada.dodaj_stan(s2_1)

# Ispis podataka o zgradi
print(zgrada)

# Vlasnici u zgradi koji u imenu imaju 'aja'
print('Vlasnici sa "aja" u imenu:\n')
for stanovi in zgrada.stanovi_vlasnika('aja').values():
    total = 0
    for stan in stanovi:
        total += stan.površina()
    #print(stan)

print(stan.vlasnik())
print('Ukupno', total, 'm2\n')
