evro=77
kurs=120
dinari=evro*kurs
print("Iznos je",dinari,"dinara")
evro=int(dinari/kurs)
print("Iznos je",evro,"evra")


