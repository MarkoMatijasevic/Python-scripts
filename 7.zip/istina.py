if(1==1):
    print("ISTINA")