x=7
y=3
if(x>=y):
	print(x)
else:
	print(y)
	