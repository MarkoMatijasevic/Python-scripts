m = 1
f = 0
gender_choice = False

while gender_choice == False:
    gender = input('Are you male or female? Type m for male or f for female. ')
    if gender == m or gender == f:
        print
        gender_choice = True
    else:
        print
        print ("Hey, this is a text based game. Read and follow bro.")

print (gender)