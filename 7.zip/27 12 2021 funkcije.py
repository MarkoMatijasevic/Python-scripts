# def say_hi():
#     print("Hello User")
# say_hi() ovako se poziva funkcija koja se zove say_hi

# def say_hi(name): ovim smo kreirali funkciju/metodu koja se zove say_hi u koju treba da se unese string koji se zove name
    # print("Hello" + name) ispisuje hello + name

# say_hi(" Mike") ovo je poziv funkcije say_hi sa imenom Mike (name)
# say_hi(" John") ovo je poziv funkcije say_hi sa imenom John (name) jedno ispod drugog sa imenom Mike u redu iznad

# def say_hi(name,age):
#     print ("Hello "+ name +", you are " + age)

# say_hi ("Mike", "35")

# def say_hi(name,age):
#     print("Hello "+name+", you are "+  str(age))

# say_hi("Mike", 35) ISTA STVAR,  samo unosis age kao string

# def cube(num):
#     return num*num*num
    
# print(cube(3)) napravili smo funkciju cube, return vraca vrednost num*num*num i na kraju ispisuje cube funkciju od broja 3

# def cube(num):
#     return num*num*num

# result = cube(3)
# print(result)







