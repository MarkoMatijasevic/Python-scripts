class Calc:
    def add(self,a,b):
        result = a + b
        return result

calc = Calc()
res = calc.add(2,3)
print(res)