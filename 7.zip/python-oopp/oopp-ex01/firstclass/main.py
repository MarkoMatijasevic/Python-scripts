import firstclass
car = firstclass.Car() 
print(car)  
