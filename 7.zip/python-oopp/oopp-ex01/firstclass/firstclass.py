class Car:
    pass

