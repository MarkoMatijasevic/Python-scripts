class Car: 
    make = ""
    model = ""
    numDoors = 0 
    wheels = 4
    def __init__(self):
        print("New car is being created")

car = Car()
