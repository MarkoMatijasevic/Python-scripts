class User:
    def __init__(self):
        self.id = ""
        self.name = ""
        self.score = ""
    #Your code here

data = "1-Peter-150"
#Your code here