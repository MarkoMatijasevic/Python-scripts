class UserPoint:
    x = 0.0
    y = 0.0

class UserPosition:
    userid = 0
    userpoint = None

data = "[{id:10,x:10,y:20},{id:5,x:30,y:40},{id:2,x:2,y:7}]"

#Your code here