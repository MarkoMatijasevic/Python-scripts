import sys
for mod in sys.modules:
    print("Module: " , mod)