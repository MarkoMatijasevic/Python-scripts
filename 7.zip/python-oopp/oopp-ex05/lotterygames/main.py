import games

games.start()