echo 'hello man\n';
echo '2 + 3 = ';
echo 2+3;
echo '\n';
