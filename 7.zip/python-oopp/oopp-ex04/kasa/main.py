import kasa,os
os.chdir("oopp-ex04/kasa")
kasa.Kasa.run()