y = 5
try:
    x = 100 / 0
    y = 10
except:
    print("Hey, you can't divide by zero!")

print(y)


