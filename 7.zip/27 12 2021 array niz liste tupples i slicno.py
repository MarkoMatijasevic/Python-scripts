lucky_numbers = [4,8,15,16,23,42]
friends = ["Kevin","Karen","Jim","Oscar", "Toby","Jim"]
friends.append("Creed")
friends.insert(1,"Kelly")
friends.remove("Oscar")
# friends[1]="Mike" - element na poziciji 1 ( drugi po redu jer pocinje od nule) postaje novi element koji se zove Mike
# friends.extend(lucky_numbers) dodaje listu lucky numbers na listu friends
# friends.sort() sortira po alphabetical orderu sve elemente u nizu friends
# friends.clear() brise sve elemente iz liste friends
# friends.pop() izbacuje samo poslednji element koji se nalazi u nizu friends
# print(friends.index("Jim")) pokazuje gde se nalazi element Jim u nizu friends
# print(friends.count("Jim")) broji koliko elemenata Jim se nalazi u nizu friends
# lucky_numbers.reverse() obrnuo je redosled elemenata unazad u nizu koji se zove lucky_numbers
# print(friends)
#print(lucky_numbers)

# friends2=friends.copy() novi niz koji se zove friends2 postaje kopija niza friends

# print(friends2)
# coordinates = (4,5) ovo je Tuple koji je imutable, ne mogu se menjati elementi u takvom nizu
# coordinates[1]=10 ovo je primer kako smo pokusali da promenimo element na poziciji 1 u tuple koji se zove coordinates, ne moze. U takvom slucaju se pravi Lista koja pocinje sa obicnom zagradom ()



