db_username = "peter"
db_password = "123"
#Your code here
username = input("Username: ")
password = input("Password: ")
print(db_username == username and db_password == password)