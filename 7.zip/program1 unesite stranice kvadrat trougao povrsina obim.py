a=int(input("Unesite stranica:"))
izbor = input("Izaberite opciju: P - povrsina, O - obim, X - izlaz")
if izbor == "O":
    rez =4*a
else:
    rez=a*a
    print(rez)
    