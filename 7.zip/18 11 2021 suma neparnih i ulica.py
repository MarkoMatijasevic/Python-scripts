ulica = [1,3,2,9,7]
print(ulica[0])
print(ulica[1])
print(ulica[2])
print(ulica[3])
print(ulica[4])
for i in range(0,5):# i uzima 0,1,2,3,4 pozicije
    print(ulica[i],end=" ")
print(ulica)
for i in ulica:# i uzima 1,3,2,9,7 sadrzaj
    print(i,end=" ")

maksi=ulica[0]
for i in range(1,len(ulica)):
    if(ulica[i]>maksi):
            maksi=ulica[i]
print("Maksimum je",maksi)

for i in range(0,len(ulica)):
    if(i%2==0):
        print(ulica[i])

print(len(ulica))
brojElemenata=0
for i in ulica :
    brojElemenata+=1
print(brojElemenata)
suma=0
for i in ulica:
    suma+=i
print("Suma je", suma)

for i in range (1,len(ulica)):
    if(i%2==0):
        suma+=ulica[i]
print("Suma je",suma)

sumaNeparnih=0
for i in ulica:
    if(i%2==1):
        sumaNeparnih+=i
print(sumaNeparnih)

