# n=10
# a= [0]*(n+1)
# a[0]=1
# for i in range(1,n):
#     a[i]=i*a[i-1]

# print(a)





#rekurzivno resenje
# n=15
# factTable = (n+1)*[0]
# def factorial(n):
#     if(n==0):
#         factTable[0] = 1
#         return 1
#     else:
#         factTable[n] = n*factorial(n-1)
#         return factTable[n]

# print(factorial(n))
# print(factTable)