import mysql.connector
class Baza:
    def __init__(self):
        self.__db = self.konekcija()
        self.__cursor = self.__db.cursor()
        
    def konekcija(self):
        return mysql.connector.connect(user='root', password='',host='127.0.0.1',database='sakila')

    def unesiShemuNaKojuSePrijavljujes(self):
        print("Unesi semu:")
        sema = str(input())
        upit = "USE "+sema
        print(upit)
        self.__cursor.execute(upit)

    

b=Baza()
b.unesiShemuNaKojuSePrijavljujes()
