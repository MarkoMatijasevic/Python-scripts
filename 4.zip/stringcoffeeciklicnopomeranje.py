from re import S


s1="coffee"
s2="eecoff"

def pomeri(s1,s2):
    if (s1==s2):
        return 0 # da ne ulazimo uopste u petlju ako su isti s1 i s2
    if (len(s1)!=len(s2)):
        return -1 # da ne ulazimo uopste u petlju ako su stringovi razlicite duzine


    for i in range(1,len(s1)):
        S=s1[-1]+s1[:-1]
        s1=S
        if(s1==s2):
            return i # ako su isti da vrati (i)
    return -1 # ovo ce pokriti sve ostale slucajeve ako nisu isti

print (pomeri(s1,s2)) # ispisace koliko ciklicnih okretanja je potrebno da s1 string izgleda isto kao s2 string





