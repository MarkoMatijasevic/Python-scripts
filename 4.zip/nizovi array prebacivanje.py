#slice je nova sekvenca generisana prema karakteristikama i odabranim clanovima postojece sekvence
#sintaksa za slice je :
#sekvenca[pocetni clan:ekskluzivni poslednji clan:korak]
#-------------------------------------------------------------
#a=[3,5,7,3,8,9]
#print(a) opcija jedan 
#print(a[2:5]) opcija 2,
#print(a[:3]) opcija 3, prikazao je 0,1,2 poziciju
#print(a[1:-1]) sklonio je prvu nultu poziciju i poslednji
#print(a[:-1]) sklonio je poslednji
#print(a[0:5])
#print(a[-3:-2])
#print(a[0:4:2]) ispisuje prvi : ide do cetvrtog: ispisuje svaki drugi kao korak
#print(a[::-1]) ide obrnuti niz

# zadatak: sabrati prvi iz niza sa prvim iz drugog niza

''''a=1,2,3 uneli smo niz
b=4,5,6 uneli smo niz
c=[] uneli smo novi prazan niz koji cemo da punimo
for i in range(len(a)): i uzima pozicije 0,1,2
    c.append(a[i]+b[i]) popunjava novi c niz koji sabira'''

# zadatak niz a: prebaciti neparne elemente ubacite u niz odd, parne u niz even
'''a=[3,7,1,9,2,4,5,12]
odd=[]
even=[]
for i in a:
    if(i%2==0):
        even.append(i)
    else:
        odd.append(i)
print(odd,even)'''




# sledeca lekcija PALINDROM - kada se niz isto cita unapred i unazad

'''
a=[1,2,3,3,2,1]
b=a[::-1]
print(a)
print(b)
if(a==b):
    print("DA")
else:
    print("NE")

ind=True *odredjujemo ind-indikator kao True
for i in range(len(a)//2): ovaj deo ide do sredine petlje
     if(a[i]!=a[len(a)-1-i]): ovaj deo proverava da li je u pitanju palindrom
        int=False

        break
if (ind==True):
    print("JESTE")
else:
    print("NIJE")
'''


    
