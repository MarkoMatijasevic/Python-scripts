python -m pip install mysql-connector-python

-------------------------------

import mysql.connector

#if this page is executed with no errors, you have the "mysql.connector" module installed.

-------------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password=""
)

print(mydb)

--------------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password=""
)

mycursor = mydb.cursor()

mycursor.execute("CREATE DATABASE mydatabase")

-------------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password=""
)
mycursor = mydb.cursor()

mycursor.execute("SHOW DATABASES")

for x in mycursor:
  print(x)
  
-------------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="sakila"
)

---------------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="datacamp"
)

mycursor = mydb.cursor()

mycursor.execute("CREATE TABLE customers (name VARCHAR(255), address VARCHAR(255))")

mycursor.execute("ALTER TABLE customers ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY")

Ili u jednoj komandi:

mycursor.execute("CREATE TABLE customers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), address VARCHAR(255))")

------------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="datacamp"
)

mycursor = mydb.cursor()

mycursor.execute("CREATE TABLE customers (name VARCHAR(255), address VARCHAR(255))")

mycursor.execute("ALTER TABLE customers ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY")

mycursor = mydb.cursor()

mycursor.execute("SHOW TABLES")

for x in mycursor:
  print(x)
-----------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="datacamp"
)

mycursor = mydb.cursor()

sql = "INSERT INTO customers (name, address) VALUES (%s, %s)"
val = ("John", "Highway 21")
mycursor.execute(sql, val)

mydb.commit()

print(mycursor.rowcount, "record inserted.")

print("1 record inserted, ID:", mycursor.lastrowid)

----------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="datacamp"
)

mycursor = mydb.cursor()

sql = "INSERT INTO customers (name, address) VALUES (%s, %s)"
val = [
  ('Peter', 'Lowstreet 4'),
  ('Amy', 'Apple st 652'),
  ('Hannah', 'Mountain 21'),
  ('Michael', 'Valley 345'),
  ('Sandy', 'Ocean blvd 2'),
  ('Betty', 'Green Grass 1'),
  ('Richard', 'Sky st 331'),
  ('Susan', 'One way 98'),
  ('Vicky', 'Yellow Garden 2'),
  ('Ben', 'Park Lane 38'),
  ('William', 'Central st 954'),
  ('Chuck', 'Main Road 989'),
  ('Viola', 'Sideway 1633')
]

mycursor.executemany(sql, val)

mydb.commit()

print(mycursor.rowcount, "was inserted.")

--------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="datacamp"
)

mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM customers")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
mycursor.execute("SELECT name, address FROM customers")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
mycursor.execute("SELECT * FROM customers")

myresult = mycursor.fetchone() #vracanje jednog reda

print(myresult)

sql = "SELECT * FROM customers WHERE address ='Park Lane 38'"

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
sql = "SELECT * FROM customers WHERE address LIKE '%way%'"

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
sql = "SELECT * FROM customers WHERE address = %s" #zastita od SQL Injection napada
adr = ("Yellow Garden 2", )

mycursor.execute(sql, adr)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
sql = "SELECT * FROM customers ORDER BY name"

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
sql = "SELECT * FROM customers ORDER BY name desc"

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
sql = "DELETE FROM customers WHERE address = 'Mountain 21'"

mycursor.execute(sql)

mydb.commit()

print(mycursor.rowcount, "record(s) deleted")

sql = "DELETE FROM customers WHERE address = %s"

adr = ("Yellow Garden 2", )

mycursor.execute(sql, adr)

mydb.commit()

print(mycursor.rowcount, "record(s) deleted")

sql = "DROP TABLE customers"

mycursor.execute(sql)

sql = "DROP TABLE IF EXISTS customers"

mycursor.execute(sql)

sql = "UPDATE customers SET address = 'Canyon 123' WHERE address = 'Valley 345'"

mycursor.execute(sql)

mydb.commit()

print(mycursor.rowcount, "record(s) affected")

sql = "UPDATE customers SET address = %s WHERE address = %s"
val = ("Valley 345", "Canyon 123")

mycursor.execute(sql, val)

mydb.commit()

print(mycursor.rowcount, "record(s) affected")

mycursor.execute("SELECT * FROM customers LIMIT 5")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
mycursor.execute("SELECT * FROM customers LIMIT 5 OFFSET 2")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
-----------------------------
  
import mysql.connector

mydb = mysql.connector.connect(user='root', password='',host='127.0.0.1',database='sakila')

mycursor = mydb.cursor()
# KADA JE UPIT U VISE REDOVA
sql = "select category.name, avg(length) \
from film join film_category using (film_id) join category using (category_id)\
group by category.name \
order by avg(length) desc";

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
--------------------------

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="sakila"
)

mycursor = mydb.cursor()

sql = "SELECT \
  users.name AS user, \
  products.name AS favorite \
  FROM users \
  INNER JOIN products ON users.fav = products.id"

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)
  
sql = "SELECT \
  users.name AS user, \
  products.name AS favorite \
  FROM users \
  LEFT JOIN products ON users.fav = products.id"
  
sql = "SELECT \
  users.name AS user, \
  products.name AS favorite \
  FROM users \
  RIGHT JOIN products ON users.fav = products.id"
  
----------------------

from mysql.connector import (connection)

cnx = connection.MySQLConnection(user='root', password='',
    host='127.0.0.1',
    database='sakila')
cnx.close()

----------------------

from mysql.connector import connection
from mysql.connector import Error

print("Neki ispis")
try:
    connection = connection.MySQLConnection(user='root', password='',
                                 host='127.0.0.1',
                                 database='sakila')
    print("Posle")
#print(connection)

    if(connection.is_connected()):
            db_Info = connection.get_server_info()
            print("Connected to MySQL Server version ", db_Info)
            cursor = connection.cursor()
            cursor.execute("select database();")
            record = cursor.fetchone()
            print("You're connected to database: ", record)
            
    mycursor = connection.cursor()
    mycursor.execute("SELECT * FROM customer")
    myresult = mycursor.fetchall()
    for x in myresult:
                print(x)

except Error as e:
    print("Error while connecting to MySQL", e)
finally:
    if(connection.is_connected()):
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

----------PREGLED VEC JE NAVEDENO----------------

import mysql.connector as mysql
from mysql.connector import (connection)
from mysql.connector import Error


'''db = mysql.connect(
    host = "localhost",
    user = "root",
    passwd = ""
)'''

'''db = mysql.connect(
    host = "localhost",
    user = "root",
    passwd = "dbms",
    database = "datacamp"
)'''

'''db = connection.MySQLConnection(user='root', password='',host='127.0.0.1',
                                 database='sakila')'''

db = connection.MySQLConnection(user='root', password='',host='127.0.0.1')

## creating an instance of 'cursor' class which is used to execute the 'SQL' statements in 'Python'
cursor = db.cursor()

## creating a databse called 'datacamp'
## 'execute()' method is used to compile a 'SQL' statement
## below statement is used to create tha 'datacamp' database

#cursor.execute("CREATE DATABASE datacamp")

## executing the statement using 'execute()' method
cursor.execute("SHOW DATABASES")

## 'fetchall()' method fetches all the rows from the last executed statement
databases = cursor.fetchall() ## it returns a list of all databases present

## printing the list of databases
print(databases)

## showing one by one database
for database in databases:
    print(database)
 
## use concrete database    
cursor.execute("USE datacamp");

## creating a table called 'users' in the 'datacamp' database
#cursor.execute("CREATE TABLE users (name VARCHAR(255), user_name VARCHAR(255))")

## getting all the tables which are present in 'datacamp' database
cursor.execute("SHOW TABLES")

tables = cursor.fetchall() ## it returns list of tables present in the database

## showing all the tables one by one
for table in tables:
    print(table)
    
## first we have to 'drop' the table which has already created to create it again with the 'PRIMARY KEY'
## 'DROP TABLE table_name' statement will drop the table from a database
cursor.execute("DROP TABLE users") # NE BRISE TABELU!

# PONOVNA KONEKCIJA SA NAVODJENJEM IMENA BAZE PRI KONEKCIJI
db = connection.MySQLConnection(user='root', password='',host='127.0.0.1',database='datacamp')

cursor = db.cursor()

#cursor.execute("DROP TABLE users")

cursor.execute("DROP TABLE IF EXISTS users")

cursor.execute("SHOW TABLES FROM DATACAMP")

tables = cursor.fetchall() ## it returns list of tables present in the database

## showing all the tables one by one
for table in tables:
    print(table)

## creating the 'users' table again with the 'PRIMARY KEY'
cursor.execute("CREATE TABLE users (id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), user_name VARCHAR(255))")

## 'DESC table_name' is used to get all columns information
cursor.execute("DESC users")

## it will print all the columns as 'tuples' in a list
print(cursor.fetchall())

-------------------------

import mysql.connector as mysql
from mysql.connector import (connection)
from mysql.connector import Error

# PONOVNA KONEKCIJA SA NAVODJENJEM IMENA BAZE PRI KONEKCIJI
db = connection.MySQLConnection(user='root', password='',host='127.0.0.1',database='datacamp')

cursor = db.cursor()

#cursor.execute("DROP TABLE users")

cursor.execute("DROP TABLE IF EXISTS users")

cursor.execute("SHOW TABLES FROM DATACAMP")

tables = cursor.fetchall() ## it returns list of tables present in the database

## showing all the tables one by one
for table in tables:
    print(table)

## creating the 'users' table again with the 'PRIMARY KEY'
cursor.execute("CREATE TABLE users (id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), user_name VARCHAR(255))")

## 'DESC table_name' is used to get all columns information
cursor.execute("DESC users")

## it will print all the columns as 'tuples' in a list
print(cursor.fetchall())

## dropping the 'id' column (I SAMIM TIM BRISANJE PRIMARNOG KLJUCA)
cursor.execute("ALTER TABLE users DROP id")

cursor.execute("DESC users")

print(cursor.fetchall())

## adding 'id' column to the 'users' table
## 'FIRST' keyword in the statement will add a column in the starting of the table
cursor.execute("ALTER TABLE users ADD COLUMN id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST")

cursor.execute("DESC users")

print(cursor.fetchall())

## defining the Query
query = "INSERT INTO users (name, user_name) VALUES (%s, %s)"
## storing values in a variable
values = ("Hafeez", "hafeez")

## executing the query with values
cursor.execute(query, values)

## to make final output we have to run the 'commit()' method of the database object
db.commit()

print(cursor.rowcount, "record inserted")

## defining the Query
query = "INSERT INTO users (name, user_name) VALUES (%s, %s)"
## storing values in a variable
values = [
    ("Peter", "peter"),
    ("Amy", "amy"),
    ("Michael", "michael"),
    ("Hennah", "hennah")
]

## executing the query with values
cursor.executemany(query, values)

## to make final output we have to run the 'commit()' method of the database object
db.commit()

print(cursor.rowcount, "records inserted")

## defining the Query
query = "SELECT * FROM users"

## getting records from the table
cursor.execute(query)

## fetching all records from the 'cursor' object
records = cursor.fetchall()

## Showing the data
for record in records:
    print(record)
    
query = "SELECT user_name FROM users"

## getting 'user_name' column from the table
cursor.execute(query)

## fetching all usernames from the 'cursor' object
usernames = cursor.fetchall()

## Showing the data
for username in usernames:
    print(username)
    
## defining the Query
query = "SELECT name, user_name FROM users"

## getting 'name', 'user_name' columns from the table
cursor.execute(query)

## fetching all records from the 'cursor' object
data = cursor.fetchall()

## Showing the data
for pair in data:
    print(pair)
    
## defining the Query
query = "SELECT * FROM users WHERE id = 5"

## getting records from the table
cursor.execute(query)

## fetching all records from the 'cursor' object
records = cursor.fetchall()

## Showing the data
for record in records:
    print(record)
    
## defining the Query
query = "SELECT * FROM users ORDER BY name"

## getting records from the table
cursor.execute(query)

## fetching all records from the 'cursor' object
records = cursor.fetchall()

## Showing the data
for record in records:
    print(record)
    
## defining the Query
query = "SELECT * FROM users ORDER BY name DESC"

## getting records from the table
cursor.execute(query)

## fetching all records from the 'cursor' object
records = cursor.fetchall()

## Showing the data
for record in records:
    print(record)
    
## defining the Query
query = "DELETE FROM users WHERE id = 5"

## executing the query
cursor.execute(query)

## final step to tell the database that we have changed the table data
db.commit()

## defining the Query
query = "SELECT * FROM users"

## getting records from the table
cursor.execute(query)

## fetching all records from the 'cursor' object
records = cursor.fetchall()

## Showing the data
for record in records:
    print(record)
    
## defining the Query
query = "UPDATE users SET name = 'Kareem' WHERE id = 1"

## executing the query
cursor.execute(query)

## final step to tell the database that we have changed the table data
db.commit()

## defining the Query
query = "SELECT * FROM users"

## getting records from the table
cursor.execute(query)

## fetching all records from the 'cursor' object
records = cursor.fetchall()

## Showing the data
for record in records:
    print(record)
	
------------------------

import mysql.connector
class Baza:
    def __init__(self):
        self.__db = self.konekcija()
        self.__cursor = self.__db.cursor()
        
    def konekcija(self):
        return mysql.connector.connect(user='root', password='',host='127.0.0.1',database='sakila')

    def unesiShemuNaKojuSePrijavljujes(self):
        print("Unesi semu:")
        sema = str(input())
        upit = "USE "+sema
        print(upit)
        self.__cursor.execute(upit)
        
    def prikaziTabele(self):
        self.__cursor.execute("SHOW TABLES")
        tables = self.__cursor.fetchall() 
        for table in tables:
            print(table)
    def listajSadrzajIzTabele(self,tabela):
        self.__cursor.execute("SELECT * FROM "+tabela)
        records = self.__cursor.fetchall()
        for record in records:
            print(record)
    def obrisiPodatakPoIDu(self,id):
        try:
            self.__cursor.execute("DELETE FROM users WHERE id = "+id)
            records = self.__cursor.fetchall()
            for record in records:
                print(record)     
            self.__db.commit()
        except:
            self.__db.rollback()
            
b = Baza()
b.prikaziTabele()
b.unesiShemuNaKojuSePrijavljujes()
b.prikaziTabele()
b.listajSadrzajIzTabele("users")
print("Unesi id za brisanje ")
b.obrisiPodatakPoIDu(input())
b.listajSadrzajIzTabele("users")
        
        
    