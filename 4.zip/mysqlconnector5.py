import mysql.connector

mydb = mysql.connector.connect(user='root', password='',host='127.0.0.1',database='sakila')

mycursor = mydb.cursor()
# KADA JE UPIT U VISE REDOVA
sql = "select category.name, avg(length) \
from film join film_category using (film_id) join category using (category_id)\
group by category.name \
order by avg(length) desc";

mycursor.execute(sql)

myresult = mycursor.fetchall()

for x in myresult:
  print(x)