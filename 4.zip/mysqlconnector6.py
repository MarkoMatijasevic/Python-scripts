import mysql.connector
class Baza:
    def __init__(self):
        self.__db = self.konekcija()
        self.__cursor = self.__db.cursor()
        
    def konekcija(self):
        return mysql.connector.connect(user='root', password='',host='127.0.0.1',database='sakila')

    def unesiShemuNaKojuSePrijavljujes(self):
        print("Unesi semu:")
        sema = str(input())
        upit = "USE "+sema
        print(upit)
        self.__cursor.execute(upit)
        
    def prikaziTabele(self):
        self.__cursor.execute("SHOW TABLES")
        tables = self.__cursor.fetchall() 
        for table in tables:
            print(table)
    def listajSadrzajIzTabele(self,tabela):
        self.__cursor.execute("SELECT * FROM "+tabela)
        records = self.__cursor.fetchall()
        for record in records:
            print(record)
    def obrisiPodatakPoIDu(self,id):
        try:
            self.__cursor.execute("DELETE FROM users WHERE id = "+id)
            records = self.__cursor.fetchall()
            for record in records:
                print(record)     
            self.__db.commit()
        except:
            self.__db.rollback()
            
b = Baza()
b.prikaziTabele()
b.unesiShemuNaKojuSePrijavljujes()
b.prikaziTabele()
b.listajSadrzajIzTabele(str(input("Unesi tabelu  ")))
print("Unesi id za brisanje ")
b.obrisiPodatakPoIDu(input())
b.listajSadrzajIzTabele(str(input("Unesi tabelu  ")))