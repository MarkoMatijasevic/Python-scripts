
#NOVA HASHTABELA POTPUNO PRAZNA KOJU SMO RADILI NA KOSNULTACIJAMA 25/02/2022
class HashTable:
  
    # Create empty bucket list of given size
    def __init__(self, size):
        self.size = size
        self.hash_table = self.create_buckets()
  
    def create_buckets(self):
        return [[] for _ in range(self.size)]

    def __str__(self):
        return "".join(str(item) for item in self.hash_table)

hash_table = HashTable(50)
print(hash_table)


