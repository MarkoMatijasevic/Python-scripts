
# VEZBANJE 28 01 2022

# for petlja - da prodje kroz listu 1+2+3+4+5
#  a=[1,2,3,4,5]
# zbir=0
# for i in range(len(a)):
#     zbir=zbir + i 
# print(zbir)


# faktorijel
# a=[1,2,3,4,5]
# faktorijel=1
# for i in range(len(a)):
#     faktorijel = faktorijel * a[i]
# print(faktorijel)

#da ispise samo zbir parnih i zbir neparnih brojeva iz skupa a
# a= [1,2,3,4,5]
# zbirparnih=0
# zbirneparnih=0
# for i in a :
#     if i%2==0:
#         zbirparnih=zbirparnih + i 
    
#     else:
#         zbirneparnih=zbirparnih + i
        

# print ("Zbir parnih brojeva = ", zbirparnih)
# print ("Zbir neparnih =", zbirneparnih)



# da brojac samostalno pokaze duzinu (len) skupa a
# a= [1,0,3,-2,8]
# count =0
# for i in a:
#     count = count + 1
# print(count)


#  da nacrtamo kvadrat 3x3 sa plusevima
# +++
# +++
# +++

# a=3
# for i in range (a):
#     for j in range (a):
#         print("+", end="")
#     print()



# da u prvom redu ima jedan plus(+), u drugom dva, u trecem tri sa konkatenacijom str+="znak +"
# +
# ++
# +++

# a=3
# str = ""

# for i in range (a):
#     str+="+"
#     print(str)


# da u listi a napravimo dve liste koje sadrze tri plusa [ [+++],[+++]]

# a=[]
# for i in range (2):
#     vrsta =[]
#     for j in range (3):
#         vrsta.append("+")
#     a.append(vrsta)
    
# print(a)




# da napunimo novu listu c[] sa zbirom prve pozicije iz skupa a i prvom pozicijom iz skupa b i tako redom.

# a = [1,2,3]
# b = [4,5,6]
# c=[]

# for i in range (len(a)):
#     c.append(a[i]+b[i])

# print(c)


# da prodjemo kroz celu listu a i vidimo da li prvi element plus+ drugi element daje rezultat 25, i da brojac ide sve dok zbir
# dva elementa ne daje 25

# a=[8,9,10,2,23]
# k=25

# for i in range(0,len(a)-1):
#     for j in range(1,len(a)):
#         if a[i] + a[j] != k:
#             continue
#         else:
#             print(True)






# ista stvar samo kroz while petlju koja je po vremenu brze resenje

# a=[8,9,10,2,23]
# k=17

# a.sort()
# pocetak=0
# kraj = len(a)-1
# while kraj>pocetak:
#     suma=a[pocetak]+a[kraj]
#     if k>suma:
#         pocetak = pocetak+1
#     elif k<suma:
#         kraj = kraj-1
#     else:
#         print(True)
#         break


#sahovska tabla da ispise A1,A2, B1, B2 i tako dalje


# matrica = []
# sah=["A","B","C","D","E","F","G","H"]

# for i in sah:
#     vrsta = []
#     for j in range(1,len(sah)-1):
#         vrsta.append(i+str(j))
#     matrica.append(vrsta)

# print(matrica)












