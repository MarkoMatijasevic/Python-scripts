def stepen(n,k):
    if (k==1):
        return n
    else:
        z = stepen (n,k//2)
        if (k%2==0):
            P=z*z
        else:
            P=n*z*z
    return P

print(stepen(2,20))