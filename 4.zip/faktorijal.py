n=14
fakt=1
for i in range(1,n+1):
    fakt=fakt*i
    

print("Faktorijal je", fakt)

