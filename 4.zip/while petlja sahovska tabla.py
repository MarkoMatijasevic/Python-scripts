# n=8
# for i in range(n):
#     for j in range(n):
#         print("#",end="")
# print()

n=8
i=0
while(i<n):
    j=0
    while(j<n):
        print("#",end="  ")
        j+=1
    i+=1
    print()