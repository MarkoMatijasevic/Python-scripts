n=15
a= [0]*(n+1)
a[0]=1
for i in range(1,n):
    a[i]=i*a[i-1]

print(a)