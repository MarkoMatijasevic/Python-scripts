a=[1,4,5,7]
b=[2,3,6,8,9,10,11]

i=j=k=0

c=[0]*(len(a)+len(b))

while(i<len(a) and j<len(b)):
    if a[i] < b[j]:
        c[k]=a[i]
        i+=1
    else:
        c[k]=b[j]
        j+=1
    k+=1

while(j<len(b)):
    c[k]=b[j]
    j+=1
    k+=1

print(c)

