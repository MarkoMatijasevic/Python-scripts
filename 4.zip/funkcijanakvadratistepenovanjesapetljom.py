from re import X


P=1
X=2
for i in range (10):
    P=P*X

print(P)
