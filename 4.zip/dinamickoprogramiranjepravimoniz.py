# n=20
# def f(n):
#     T=[0]*(n+1)
#     T[0]=T[1]=2
#     T[2]=2*T[0]*T[1]
#     for i in range(3, n+1):
#         T[i]=T[i-1]+2*T[i-1]*T[i-2]
#     return T[n]
# print(f(n))

# def rek(n):
#     suma = 0
#     if(n==0 or n==1):
#         return 2
#     for i in range(1,n):
#         suma+= 2*rek(i)*rek(i-1)
#     return suma

# print(rek(n))


# n=10
# def f(n):
#     T=[0]*(n+1)
#     T[0]=T[1]=2
#     T[2]=2*T[0]*T[1]
#     for i in range(3, n+1):
#         T[i]=T[i-1]+2*T[i-1]*T[i-2]
#     return T[n]
# print(f(n))

# def f(n):
#     b=2
#     c=4*b
#     for i in range(3, n+1):
#         d=c+2*c*b
#         b = c
#         c = d
#     return d
# print(f(n))



# def rek(n):
#     suma = 0
#     if(n==0 or n==1):
#         return 2
#     for i in range(1,n):
#         suma+= 2*rek(i)*rek(i-1)
#     return suma

# print(rek(n))

print(10%2)