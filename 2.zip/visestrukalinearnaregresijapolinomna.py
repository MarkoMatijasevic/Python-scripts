import matplotlib.pyplot as plt
import numpy
from scipy import stats

# polinomna regresija


x = [1,2,3,5,6,7,8,9,10,12,13,14,15,16,18,19,21,22]
y = [100,90,80,60,60,55,60,65,70,70,75,76,78,79,90,99,99,100]

plt.scatter(x, y)
plt.show() 

mymodel = numpy.poly1d(numpy.polyfit(x, y, 4))

myline = numpy.linspace(1, 22, 100)

plt.scatter(x, y)
plt.plot(myline, mymodel(myline))
plt.show() 

from sklearn.metrics import r2_score
# provera koliko su dobro opisani podaci
print("R score ",r2_score(y, mymodel(x))) 
# predikcija
speed = mymodel(17)
print("PROCENA ",speed) 

#neodgovarajuci podaci

x = [89,43,36,36,95,10,66,34,38,20,26,29,48,64,6,5,36,66,72,40]
y = [21,46,3,35,67,95,53,72,58,10,26,34,90,33,38,20,56,2,47,15]

mymodel = numpy.poly1d(numpy.polyfit(x, y, 3))

myline = numpy.linspace(2, 95, 100)

plt.scatter(x, y)
plt.plot(myline, mymodel(myline))
plt.show() 

print(r2_score(y, mymodel(x)))


import numpy
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
numpy.random.seed(2)

x = numpy.random.normal(3, 1, 100)
y = numpy.random.normal(150, 40, 100) / x

plt.scatter(x, y)
plt.show() 

train_x = x[:80]
train_y = y[:80]

test_x = x[80:]
test_y = y[80:] 

plt.scatter(train_x, train_y)
plt.show() 

plt.scatter(test_x, test_y)
plt.show() 

mymodel = numpy.poly1d(numpy.polyfit(train_x, train_y, 4))

myline = numpy.linspace(0, 6, 100)

plt.scatter(train_x, train_y)
plt.plot(myline, mymodel(myline))
plt.show() 

r2 = r2_score(train_y, mymodel(train_x)) # value ranges from 0 to 1

print(r2) 

# provera sa testnim setom

mymodel = numpy.poly1d(numpy.polyfit(train_x, train_y, 4))

r2 = r2_score(test_y, mymodel(test_x))

print(r2) 

print(mymodel(5)) 