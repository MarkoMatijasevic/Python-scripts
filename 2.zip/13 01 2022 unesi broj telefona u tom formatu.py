
#format broja mora da bude 063/123-456

import re

pattern = re.compile("^\d{3}/\d{3}-\d{3}$")
unos = input ("Enter phone number: ")
print(pattern.search(unos))




