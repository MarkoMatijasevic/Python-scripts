def row_sum_odd_numbers(n):
    k=n*(n-1)+1
    j=k+((n-1)*2)
    sum=0
    for i in range (k,j+1,2):
        sum=sum+i
    return sum
        
    


print(row_sum_odd_numbers(6))



#resenje sa codewarsa
# def row_sum_odd_numbers(n):
#     return n**3