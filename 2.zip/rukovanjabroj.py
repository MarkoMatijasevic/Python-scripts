def get_participants(handshakes):
    return handshakes*(handshakes-1)/2

print(int(get_participants(16)))



#resenje zadatka sa codewarsa

# def get_participants(handshakes, n = 1):
#     return get_participants(handshakes, n + 1) if (n * n - n)/2 < handshakes else n

# print(get_participants(16))

 




