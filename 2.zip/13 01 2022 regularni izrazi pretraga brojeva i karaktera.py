import re

pattern = re.compile ("^(marko\.caric@gmail.com)$")
unos = input ("Enter e-mail address: ")
print (pattern.search(unos))
