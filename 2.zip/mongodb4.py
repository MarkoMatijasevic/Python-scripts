# -*- coding: utf-8 -*-
"""
Created on Fri Jul 30 11:35:37 2021

@author: Acer
"""

import pymongo

myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["mydatabase2"]
mycol = mydb["customers"]

myquery = { "address": "Park Lane 38" }

mydoc = mycol.find(myquery)

for x in mydoc:
  print(x)
  
print("--------------------------------")
  
myquery = { "address": { "$gt": "S" } }

mydoc = mycol.find(myquery)

for x in mydoc:
  print(x)
  
print("--------------------------------")
  
myquery = { "address": { "$regex": "^S" } }

mydoc = mycol.find(myquery)

for x in mydoc:
  print(x)
  
print("--------------------------------")
  
mydoc = mycol.find().sort("name")

for x in mydoc:
  print(x)
  
print("--------------------------------")
  
mydoc = mycol.find().sort("name", -1)

for x in mydoc:
  print(x)
  
