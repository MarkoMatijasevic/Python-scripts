for i in range(0,11):
    for j in range(0,11):
        print(i,"*",j,"=",i*j)
        
