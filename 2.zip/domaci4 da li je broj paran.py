a=int(input("Unesi broj: "))
print("Parnost je ",a%2==0)
