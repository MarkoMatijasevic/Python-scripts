
import pandas as pd

sms_spam = pd.read_csv('SMSSpamCollection', sep='\t',
header=None, names=['Label','SMS'])

print(sms_spam.shape)
print(sms_spam.head())
print(sms_spam)

print(sms_spam['Label'].value_counts(normalize=True))

# Randomize the dataset
data_randomized = sms_spam.sample(frac=1, random_state=1)

# Calculate index for split
training_test_index = round(len(data_randomized) * 0.8)

# Split into training and test sets
training_set = data_randomized[:training_test_index].reset_index(drop=True)
test_set = data_randomized[training_test_index:].reset_index(drop=True)

print(training_set.shape)
print(test_set.shape)
print("------------------")

print(training_set['Label'].value_counts(normalize=True))
print("------------------")
print(test_set['Label'].value_counts(normalize=True))
 
# Before cleaning
print(training_set.head(3))
 
# After cleaning
training_set['SMS'] = training_set['SMS'].str.replace('\W', ' ') # Removes punctuation # \W znaci sve sto nije rec
training_set['SMS'] = training_set['SMS'].str.lower()
print(training_set.head(3))


training_set['SMS'] = training_set['SMS'].str.split()
print(training_set)

vocabulary = []
for sms in training_set['SMS']:
   for word in sms:
      vocabulary.append(word)

vocabulary = list(set(vocabulary)) # set (skup) briše duplikate

print(vocabulary)

word_counts_per_sms = {unique_word: [0] * len(training_set['SMS']) for unique_word in vocabulary}

for index, sms in enumerate(training_set['SMS']):
   for word in sms:
      word_counts_per_sms[word][index] += 1
      
word_counts = pd.DataFrame(word_counts_per_sms)
print(word_counts.head())

training_set_clean = pd.concat([training_set, word_counts], axis=1)
print("Ociscen trenazni skup")
print(training_set_clean.head())
print("Duzina trenaznog skupa ",len(training_set_clean))

# Isolating spam and ham messages first
spam_messages = training_set_clean[training_set_clean['Label'] == 'spam'] # sve poruke koje su spam
ham_messages = training_set_clean[training_set_clean['Label'] == 'ham'] # sve poruke koje nisu spam




