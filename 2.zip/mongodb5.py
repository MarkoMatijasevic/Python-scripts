# -*- coding: utf-8 -*-
"""
Created on Fri Jul 30 11:44:01 2021

@author: Acer
"""
import pymongo

myclient = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = myclient["mydatabase"]
mycol = mydb["customers"]

mydoc = mycol.find().sort("address")

for x in mydoc:
  print(x)
  
print("--------------------------------")

myquery = { "address": "Mountain 21" }

mycol.delete_one(myquery)

mydoc = mycol.find().sort("address")

myquery = { "address": {"$regex": "^S"} }

x = mycol.delete_many(myquery)

print(x.deleted_count, " documents deleted.")

for x in mydoc:
  print(x)
  
print("--------------------------------")

