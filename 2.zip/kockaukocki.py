def not_visible_cubes(n):
    return max(n - 2, 0) ** 3