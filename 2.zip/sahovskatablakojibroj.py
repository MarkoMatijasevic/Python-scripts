
def square(number):

    for i in range (number):
        result=2
        result=result**i
    return result
print(square(5))
